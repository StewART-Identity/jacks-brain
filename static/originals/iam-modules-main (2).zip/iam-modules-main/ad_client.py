"""
Active Directory Domain Controller Client.

Provides read/write capabilities for a specific AD domain.
For forest-wide searches, use ADGlobalCatalogClient from gc_client module.
"""

from __future__ import annotations

import logging
import os
from typing import Any

# Optional LDAP support
try:
    import ldap3  # noqa: F401
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False


class ADDomainControllerClient:
    """
    Client for Active Directory Domain Controller LDAP operations (read/write).

    Use this client for modifying AD objects. For forest-wide searches,
    use ADGlobalCatalogClient instead.

    Example using from_config::

        from iam_modules import load_config, setup_logging

        config = load_config(__file__)
        logger = setup_logging('my_script')

        client = ADDomainControllerClient.from_config(config, 'unt', logger)
        if client.connect():
            client.add_group_member(group_dn, user_dn)
            client.disconnect()
    """

    def __init__(self, hostname: str, port: int, use_ssl: bool,
                 username: str, password: str, base_dn: str,
                 logger: logging.Logger | None = None):
        self.hostname = hostname
        self.port = port
        self.use_ssl = use_ssl
        self.username = username
        self.password = password
        self.base_dn = base_dn
        self.logger = logger or logging.getLogger(__name__)
        self.connection: Any = None  # ldap3.Connection when connected

    @classmethod
    def from_config(cls, config: dict[str, Any], domain: str,
                    logger: logging.Logger | None = None) -> 'ADDomainControllerClient':
        """
        Create an ADDomainControllerClient from a load_config() dict.

        Args:
            config: Configuration dict from load_config().
            domain: Domain short name ('ad', 'hsc', 'students', 'unt').
            logger: Optional logger instance.

        Returns:
            Configured (but not yet connected) ADDomainControllerClient.

        Raises:
            ValueError: If domain is not valid.
        """
        from .config import VALID_AD_DOMAINS

        domain_lower = domain.lower()
        if domain_lower not in VALID_AD_DOMAINS:
            raise ValueError(
                f"Invalid domain '{domain}'. "
                f"Must be one of: {', '.join(VALID_AD_DOMAINS)}"
            )

        ad_cfg = config[f'ad_{domain_lower}']
        return cls(
            hostname=ad_cfg['hostname'],
            port=ad_cfg['port'],
            use_ssl=ad_cfg['use_ssl'],
            username=ad_cfg['username'],
            password=ad_cfg['password'],
            base_dn=ad_cfg['base_dn'],
            logger=logger
        )

    def connect(self) -> bool:
        """
        Establish connection to the Domain Controller.

        Returns:
            True if connection successful, False otherwise
        """
        if not LDAP_AVAILABLE:
            self.logger.error(
                "ldap3 library not available. Install with: pip install ldap3"
            )
            return False

        from ldap3 import Server as LdapServer, Connection as LdapConnection
        from .tls import ad_tls

        try:
            self.logger.debug(
                f"Connecting to DC: {self.hostname}:{self.port} "
                f"(SSL: {self.use_ssl})"
            )

            if self.use_ssl:
                server = LdapServer(
                    self.hostname, port=self.port,
                    use_ssl=True, tls=ad_tls(), get_info='ALL',
                    connect_timeout=30
                )
            else:
                server = LdapServer(
                    self.hostname, port=self.port,
                    get_info='ALL', connect_timeout=30
                )

            self.connection = LdapConnection(
                server,
                user=self.username,
                password=self.password,
                auto_bind=True,
                raise_exceptions=True
            )

            self.logger.debug(
                f"Successfully connected to Domain Controller: "
                f"{self.hostname}"
            )
            return True

        except Exception as e:
            self.logger.error(f"Failed to connect to Domain Controller: {e}")
            return False

    def disconnect(self) -> None:
        """Close the LDAP connection."""
        if self.connection:
            try:
                self.connection.unbind()
            except Exception:
                pass
            self.connection = None

    def add_group_member(self, group_dn: str, user_dn: str,
                         dry_run: bool = False) -> bool:
        """Add a user to a group."""
        if not self.connection:
            return False
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would add '{user_dn}' to group '{group_dn}'")
            return True

        from ldap3 import MODIFY_ADD as LDAP_MODIFY_ADD
        from ldap3.core.exceptions import LDAPException

        try:
            self.connection.modify(
                group_dn,
                {'member': [(LDAP_MODIFY_ADD, [user_dn])]}
            )
            self.logger.debug(f"Successfully added '{user_dn}' to group '{group_dn}'")
            return True
        except LDAPException as e:
            err = str(e).lower()
            if 'already exists' in err or 'attributeorvalueexists' in err:
                self.logger.warning(f"User '{user_dn}' is already a member of group '{group_dn}'")
                return True
            self.logger.error(f"Error adding user to group: {e}")
            return False

    def remove_group_member(self, group_dn: str, user_dn: str,
                            dry_run: bool = False) -> bool:
        """Remove a user from a group."""
        if not self.connection:
            return False
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would remove '{user_dn}' from group '{group_dn}'")
            return True

        from ldap3 import MODIFY_DELETE as LDAP_MODIFY_DELETE
        from ldap3.core.exceptions import LDAPException

        try:
            self.connection.modify(
                group_dn,
                {'member': [(LDAP_MODIFY_DELETE, [user_dn])]}
            )
            self.logger.debug(f"Successfully removed '{user_dn}' from group '{group_dn}'")
            return True
        except LDAPException as e:
            self.logger.error(f"Error removing user from group: {e}")
            return False

    def modify_attribute(self, dn: str, attribute: str, value: Any,
                         operation: str = 'replace', dry_run: bool = False) -> bool:
        """Modify an attribute on an AD object."""
        if not self.connection:
            return False
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would {operation} '{attribute}' on '{dn}'")
            return True

        from ldap3 import MODIFY_REPLACE, MODIFY_ADD, MODIFY_DELETE

        op_map = {
            'replace': MODIFY_REPLACE,
            'add': MODIFY_ADD,
            'delete': MODIFY_DELETE
        }
        ldap_op = op_map.get(operation.lower())
        if not ldap_op:
            self.logger.error(f"Invalid operation: {operation}")
            return False

        try:
            if not isinstance(value, list):
                value = [value]
            self.connection.modify(dn, {attribute: [(ldap_op, value)]})
            self.logger.debug(f"Successfully modified '{attribute}' on '{dn}'")
            return True
        except Exception as e:
            self.logger.error(f"Error modifying attribute: {e}")
            return False

    def search(self, search_filter: str, attributes: list[str] | None = None,
               search_base: str | None = None) -> list[dict[str, Any]]:
        """Search for objects in the domain."""
        if not self.connection:
            return []

        from ldap3 import SUBTREE as LDAP_SUBTREE

        try:
            self.connection.search(
                search_base=search_base or self.base_dn,
                search_filter=search_filter,
                search_scope=LDAP_SUBTREE,
                attributes=attributes or ['*']
            )
            results = []
            for entry in self.connection.entries:
                result = {'dn': str(entry.entry_dn)}
                for attr in entry.entry_attributes:
                    val = entry[attr].value
                    result[attr] = val
                results.append(result)
            return results
        except Exception as e:
            self.logger.error(f"Error searching: {e}")
            return []


def create_dc_client_for_domain(domain_dn: str,
                                logger: logging.Logger | None = None) -> ADDomainControllerClient | None:
    """
    Factory function to create a Domain Controller client for a specific domain.

    Looks up the DC configuration from environment variables based on the domain DN.
    """
    from .config import get_dc_prefix_for_domain_dn

    if logger is None:
        logger = logging.getLogger(__name__)

    prefix = get_dc_prefix_for_domain_dn(domain_dn)
    if not prefix:
        logger.error(f"No DC configuration found for domain: {domain_dn}")
        return None

    hostname = os.getenv(f"{prefix}_HOSTNAME")
    port_str = os.getenv(f"{prefix}_PORT")
    use_ssl = os.getenv(f"{prefix}_USE_SSL", "true").lower() == "true"
    username = os.getenv(f"{prefix}_USERNAME")
    password = os.getenv(f"{prefix}_PASSWORD")
    base_dn = os.getenv(f"{prefix}_SEARCHBASE")

    if not hostname or not port_str or not username or not password:
        logger.error(f"Incomplete DC configuration for {prefix}")
        return None

    if not base_dn:
        base_dn = domain_dn

    return ADDomainControllerClient(
        hostname=hostname,
        port=int(port_str),
        use_ssl=use_ssl,
        username=username,
        password=password,
        base_dn=base_dn,
        logger=logger
    )
