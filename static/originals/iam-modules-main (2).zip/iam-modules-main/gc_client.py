"""
Active Directory Global Catalog Client.

Provides read-only search capabilities across the AD forest via the Global Catalog.
For write operations, use ADDomainControllerClient from ad_client module.
"""

from __future__ import annotations

import logging
from typing import Any

# Import config helpers
from .config import extract_domain_from_dn, get_dc_prefix_for_domain_dn

# Optional LDAP support
try:
    import ldap3  # noqa: F401
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False


class ADGlobalCatalogClient:
    """
    Client for Active Directory Global Catalog LDAP operations (read-only searches).
    
    The Global Catalog provides forest-wide search capabilities but is read-only.
    Use this for finding groups and users across domains, then use ADDomainControllerClient
    for write operations.
    
    Example:
        client = ADGlobalCatalogClient(
            hostname='gc.ad.unt.edu',
            port=3269,
            use_ssl=True,
            username='user@ad.unt.edu',
            password='secret',
            base_dn='DC=ad,DC=unt,DC=edu',
            logger=logger
        )
        
        if client.connect():
            group_dn = client.find_group('MyGroup')
            users = client.find_user_by_employee_id('12345')
            client.disconnect()
    """
    
    def __init__(self, hostname: str, port: int, use_ssl: bool, 
                 username: str, password: str, base_dn: str, 
                 logger: logging.Logger | None = None):
        self.hostname = hostname
        self.port = port
        self.use_ssl = use_ssl
        self.username = username
        self.password = password
        self.base_dn = base_dn
        self.logger = logger or logging.getLogger(__name__)
        self.connection: Any = None  # ldap3.Connection when connected
    
    @classmethod
    def from_config(cls, config: dict[str, Any],
                    logger: logging.Logger | None = None) -> 'ADGlobalCatalogClient':
        """
        Create an ADGlobalCatalogClient from a load_config() dict.

        Args:
            config: Configuration dict from load_config().
            logger: Optional logger instance.

        Returns:
            Configured (but not yet connected) ADGlobalCatalogClient.
        """
        gc_cfg = config['gc']
        return cls(
            hostname=gc_cfg['hostname'],
            port=gc_cfg['port'],
            use_ssl=gc_cfg['use_ssl'],
            username=gc_cfg['username'],
            password=gc_cfg['password'],
            base_dn=gc_cfg['base_dn'],
            logger=logger
        )
    
    @staticmethod
    def extract_domain_from_dn(dn: str) -> str | None:
        """
        Extract the domain portion (DC components) from a distinguished name.
        
        Args:
            dn: Full DN (e.g., 'CN=Group,OU=Groups,DC=unt,DC=ad,DC=unt,DC=edu')
        
        Returns:
            Domain DN (e.g., 'DC=unt,DC=ad,DC=unt,DC=edu') or None
        """
        return extract_domain_from_dn(dn)
    
    @staticmethod
    def get_dc_config_prefix(domain_dn: str) -> str | None:
        """
        Get the environment variable prefix for the domain controller config.
        
        Args:
            domain_dn: Domain DN (e.g., 'DC=unt,DC=ad,DC=unt,DC=edu')
        
        Returns:
            Environment variable prefix (e.g., 'AD_UNT') or None
        """
        return get_dc_prefix_for_domain_dn(domain_dn)
    
    def connect(self) -> bool:
        """
        Establish connection to the AD Global Catalog.
        
        Returns:
            True if connection successful, False otherwise
        """
        if not LDAP_AVAILABLE:
            self.logger.error("ldap3 library not available. Install with: pip install ldap3")
            return False
        
        from ldap3 import Server as LdapServer, Connection as LdapConnection
        from .tls import ad_tls
        
        try:
            self.logger.debug(f"Connecting to AD GC: {self.hostname}:{self.port} (SSL: {self.use_ssl})")
            
            if self.use_ssl:
                server = LdapServer(self.hostname, port=self.port, use_ssl=True, tls=ad_tls(), get_info='ALL', connect_timeout=30)
            else:
                server = LdapServer(self.hostname, port=self.port, get_info='ALL', connect_timeout=30)
            
            self.connection = LdapConnection(
                server,
                user=self.username,
                password=self.password,
                auto_bind=True,
                raise_exceptions=True
            )
            
            self.logger.debug("Successfully connected to AD Global Catalog")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to AD Global Catalog: {e}")
            return False
    
    def disconnect(self) -> None:
        """Close the LDAP connection."""
        if self.connection:
            try:
                self.connection.unbind()
            except Exception:
                pass
            self.connection = None
    
    def find_group(self, group_name: str) -> str | None:
        """
        Find a group by its name (cn) in AD.
        
        Args:
            group_name: Common name of the group
        
        Returns:
            The group's distinguished name (DN) or None if not found
        """
        if not self.connection:
            return None
        
        from ldap3 import SUBTREE as LDAP_SUBTREE
        
        try:
            from ldap3.utils.conv import escape_filter_chars
            safe = escape_filter_chars(group_name)
            search_filter = f"(&(objectClass=group)(cn={safe}))"
            self.connection.search(
                search_base=self.base_dn,
                search_filter=search_filter,
                search_scope=LDAP_SUBTREE,
                attributes=['distinguishedName', 'cn']
            )
            
            if self.connection.entries:
                dn = str(self.connection.entries[0].distinguishedName)
                self.logger.debug(f"Found group '{group_name}' at: {dn}")
                return dn
            
            self.logger.debug(f"Group '{group_name}' not found in AD")
            return None
            
        except Exception as e:
            self.logger.error(f"Error searching for group '{group_name}': {e}")
            return None
    
    def find_user_by_upn(self, upn: str) -> dict[str, Any] | None:
        """
        Find a user by their userPrincipalName.
        
        Args:
            upn: User principal name (e.g., 'user@domain.edu')
        
        Returns:
            Dict with dn, sAMAccountName, userPrincipalName, displayName, employeeID
            or None if not found
        """
        if not self.connection:
            return None
        
        from ldap3 import SUBTREE as LDAP_SUBTREE
        
        try:
            from ldap3.utils.conv import escape_filter_chars
            safe = escape_filter_chars(upn)
            search_filter = f"(&(objectClass=user)(userPrincipalName={safe}))"
            self.connection.search(
                search_base=self.base_dn,
                search_filter=search_filter,
                search_scope=LDAP_SUBTREE,
                attributes=['distinguishedName', 'sAMAccountName', 'userPrincipalName', 'displayName', 'employeeID']
            )
            
            if self.connection.entries:
                entry = self.connection.entries[0]
                return {
                    'dn': str(entry.distinguishedName),
                    'sAMAccountName': str(entry.sAMAccountName) if entry.sAMAccountName else None,
                    'userPrincipalName': str(entry.userPrincipalName) if entry.userPrincipalName else None,
                    'displayName': str(entry.displayName) if entry.displayName else None,
                    'employeeID': str(entry.employeeID) if entry.employeeID else None
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error searching for user by UPN '{upn}': {e}")
            return None
    
    def find_user_by_employee_id(self, employee_id: str) -> list[dict[str, Any]]:
        """
        Find users by their employeeID.
        
        Note: May return multiple users in multi-domain environments.
        
        Args:
            employee_id: Employee ID to search for
        
        Returns:
            List of dicts with dn, sAMAccountName, userPrincipalName, displayName, employeeID
        """
        if not self.connection:
            return []
        
        from ldap3 import SUBTREE as LDAP_SUBTREE
        
        try:
            from ldap3.utils.conv import escape_filter_chars
            safe = escape_filter_chars(employee_id)
            search_filter = f"(&(objectClass=user)(employeeID={safe}))"
            self.connection.search(
                search_base=self.base_dn,
                search_filter=search_filter,
                search_scope=LDAP_SUBTREE,
                attributes=['distinguishedName', 'sAMAccountName', 'userPrincipalName', 'displayName', 'employeeID']
            )
            
            users = []
            for entry in self.connection.entries:
                users.append({
                    'dn': str(entry.distinguishedName),
                    'sAMAccountName': str(entry.sAMAccountName) if entry.sAMAccountName else None,
                    'userPrincipalName': str(entry.userPrincipalName) if entry.userPrincipalName else None,
                    'displayName': str(entry.displayName) if entry.displayName else None,
                    'employeeID': str(entry.employeeID) if entry.employeeID else None
                })
            
            return users
            
        except Exception as e:
            self.logger.error(f"Error searching for user by employeeID '{employee_id}': {e}")
            return []
    
    def get_group_members(self, group_dn: str) -> list[str]:
        """
        Get all member DNs of a group.
        
        Args:
            group_dn: Distinguished name of the group
        
        Returns:
            List of member distinguished names
        """
        if not self.connection:
            return []
        
        try:
            self.connection.search(
                search_base=group_dn,
                search_filter="(objectClass=group)",
                search_scope='BASE',
                attributes=['member']
            )
            
            if self.connection.entries:
                members = self.connection.entries[0].member.values if self.connection.entries[0].member else []
                return [str(m) for m in members]
            
            return []
            
        except Exception as e:
            self.logger.error(f"Error getting members of group '{group_dn}': {e}")
            return []
    
    def is_user_member_of(self, user_dn: str, group_dn: str) -> bool:
        """
        Check if a user is a member of a specific group.
        
        Args:
            user_dn: User's distinguished name
            group_dn: Group's distinguished name
        
        Returns:
            True if user is a member, False otherwise
        """
        members = self.get_group_members(group_dn)
        return user_dn.lower() in [m.lower() for m in members]
    
    def resolve_user(self, identifier: str) -> dict[str, Any] | None:
        """
        Resolve a user by UPN or employeeID.
        
        Args:
            identifier: UPN (contains @) or employeeID (no @)
        
        Returns:
            User info dict or None
        
        Raises:
            ValueError: If multiple users are found for an employeeID
                       (format: "MULTIPLE_USERS:identifier:upn1|upn2|upn3")
        """
        identifier = identifier.strip()
        
        if "@" in identifier:
            return self.find_user_by_upn(identifier)
        else:
            users = self.find_user_by_employee_id(identifier)
            if len(users) == 0:
                return None
            elif len(users) == 1:
                return users[0]
            else:
                # Multiple users - raise error with details (use pipe delimiter since DNs contain commas)
                upn_list = [u.get('userPrincipalName') or u.get('dn') or 'Unknown' for u in users]
                raise ValueError(f"MULTIPLE_USERS:{identifier}:{'|'.join(upn_list)}")
