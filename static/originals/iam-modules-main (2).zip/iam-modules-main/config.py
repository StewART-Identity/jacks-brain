"""
Configuration management for UNT IAM scripts.

Handles loading environment variables from the .env file that lives
alongside this module (supporting symlinked deployments) and provides
domain-specific configuration helpers and centralized constants.

Architecture:
    The .env file is resolved relative to the *real* path of this module,
    not the symlink.  This allows multiple repos to symlink to a shared
    iam_modules directory while all reading the same .env:

        /root/scripts/
        ├── iam-modules/           ← the repo (contains .env)
        ├── iam-scripts-provisioning/
        │   └── iam_modules -> ../iam-modules/
        └── iam-dstools/
            └── iam_modules -> ../iam-modules/
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv


# =============================================================================
# Centralized Constants
# =============================================================================

# Logging
DEFAULT_LOG_DIR = Path('/var/log/iam')
DEFAULT_LOG_LEVEL = 'INFO'

# SMTP (for notification scripts)
DEFAULT_SMTP_HOST = 'localhost'
DEFAULT_SMTP_PORT = 25

# Connection timeouts (seconds)
DEFAULT_EDIR_TIMEOUT = 600    # eDirectory is slow; scripts need patience
DEFAULT_AD_TIMEOUT = 30
DEFAULT_GC_TIMEOUT = 30
DEFAULT_DB_TIMEOUT = 30

# Domain DN suffix to environment variable prefix mapping
DOMAIN_DC_MAPPING: dict[str, str] = {
    "DC=ad,DC=unt,DC=edu": "AD_AD",
    "DC=hsc,DC=ad,DC=unt,DC=edu": "AD_HSC",
    "DC=students,DC=ad,DC=unt,DC=edu": "AD_STUDENTS",
    "DC=unt,DC=ad,DC=unt,DC=edu": "AD_UNT",
}

# Valid eDirectory environments
VALID_EDIR_ENVIRONMENTS = ['test', 'prod']

# Valid AD domain names (short form)
VALID_AD_DOMAINS = ['ad', 'hsc', 'students', 'unt']

# Domains to exclude from Entra ID user lookups (internal tenant domains)
EXCLUDED_ENTRA_DOMAINS = ["myunt.onmicrosoft.com", "myunttest.onmicrosoft.com"]


# =============================================================================
# .env Resolution
# =============================================================================

def _get_module_dir() -> Path:
    """
    Return the *real* directory of this module, resolving symlinks.

    This ensures that when iam_modules is symlinked from a consuming repo,
    we still find the .env that lives next to the actual module files.
    """
    return Path(os.path.realpath(__file__)).parent


def get_env_path(script_path: str | Path | None = None) -> Path:
    """
    Get the path to the .env file.

    Resolution order:
        1. Script's own directory (if script_path provided)
        2. Script's parent directory
        3. The real iam_modules directory (symlink-safe)

    Args:
        script_path: Path to the calling script (__file__ from caller).
                     If None, goes straight to the module directory.

    Returns:
        Path to the .env file (may not exist yet).
    """
    if script_path:
        script_dir = Path(os.path.realpath(script_path)).parent

        env_path = script_dir / '.env'
        if env_path.exists():
            return env_path

        parent_env = script_dir.parent / '.env'
        if parent_env.exists():
            return parent_env

    module_env = _get_module_dir() / '.env'
    if module_env.exists():
        return module_env

    return module_env


# =============================================================================
# Configuration Loading
# =============================================================================

def _int_or_default(value: str | None, default: int) -> int:
    """Parse an int from env, falling back to default."""
    if value is None:
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def _load_ad_domain_config(prefix: str) -> dict[str, Any]:
    """Load AD domain configuration for a given env var prefix."""
    return {
        'hostname': os.getenv(f'{prefix}_HOSTNAME'),
        'port': _int_or_default(os.getenv(f'{prefix}_PORT'), 636),
        'use_ssl': os.getenv(f'{prefix}_USE_SSL', 'true').lower() == 'true',
        'username': os.getenv(f'{prefix}_USERNAME'),
        'password': os.getenv(f'{prefix}_PASSWORD'),
        'base_dn': os.getenv(f'{prefix}_SEARCHBASE'),
        'domain': os.getenv(f'{prefix}_DOMAIN'),
        'timeout': _int_or_default(os.getenv(f'{prefix}_TIMEOUT'), DEFAULT_AD_TIMEOUT),
    }


def _load_edir_config(
    prefix: str,
    fallback_prefix: str | None = None,
) -> dict[str, Any]:
    """
    Load eDirectory configuration for a given env var prefix.

    Args:
        prefix: Primary env var prefix (e.g., 'EDIR_PROD', 'EDIR_TEST').
        fallback_prefix: If set, try this prefix when the primary key is empty.
                         Used for backward compatibility (EDIR_PROD_* → EDIR_*).
    """
    def _get(key: str, default: str | None = None) -> str | None:
        val = os.getenv(f'{prefix}_{key}')
        if val:
            return val
        if fallback_prefix:
            val = os.getenv(f'{fallback_prefix}_{key}')
            if val:
                return val
        return default

    return {
        'hostname': _get('HOSTNAME'),
        'port': _int_or_default(_get('PORT'), 637),
        'use_ssl': (_get('USE_SSL', 'true') or 'true').lower() == 'true',
        'username': _get('USERNAME'),
        'password': _get('PASSWORD'),
        'base_dn': _get('SEARCHBASE'),
        'timeout': _int_or_default(_get('TIMEOUT'), DEFAULT_EDIR_TIMEOUT),
    }


def load_config(script_path: str | Path | None = None) -> dict[str, Any]:
    """
    Load configuration from .env file.

    This returns ONLY infrastructure/service connection settings.
    Application-specific variables (BATCH_*, DEACTIVATE_*, VPN_*, etc.)
    should be read by the scripts themselves via os.getenv() after
    load_config() has called load_dotenv().

    Args:
        script_path: Path to the calling script (pass __file__).

    Returns:
        Dictionary with all configuration organized by service.
    """
    env_path = get_env_path(script_path)

    if env_path.exists():
        load_dotenv(env_path)

    config: dict[str, Any] = {
        # eDirectory — environment-specific configs.
        # EDIR_PROD_* falls back to EDIR_* for backward compatibility.
        'edir_test': _load_edir_config('EDIR_TEST'),
        'edir_prod': _load_edir_config('EDIR_PROD', fallback_prefix='EDIR'),
        # AD Global Catalog
        'gc': {
            'hostname': os.getenv('AD_GC_HOSTNAME'),
            'port': _int_or_default(os.getenv('AD_GC_PORT'), 3269),
            'use_ssl': os.getenv('AD_GC_USE_SSL', 'true').lower() == 'true',
            'username': os.getenv('AD_GC_USERNAME'),
            'password': os.getenv('AD_GC_PASSWORD'),
            'base_dn': os.getenv('AD_GC_SEARCHBASE'),
            'domain': os.getenv('AD_GC_DOMAIN'),
            'timeout': _int_or_default(os.getenv('AD_GC_TIMEOUT'), DEFAULT_GC_TIMEOUT),
        },
        # AD Domains
        'ad_ad': _load_ad_domain_config('AD_AD'),
        'ad_hsc': _load_ad_domain_config('AD_HSC'),
        'ad_students': _load_ad_domain_config('AD_STUDENTS'),
        'ad_unt': _load_ad_domain_config('AD_UNT'),
        # Entra ID (Azure AD)
        'entra': {
            'tenant_id': os.getenv('ENTRA_TENANT_ID'),
            'client_id': os.getenv('ENTRA_CLIENT_ID'),
            'client_secret': os.getenv('ENTRA_CLIENT_SECRET'),
        },
        # Duo Security (Admin API)
        'duo': {
            'api_hostname': os.getenv('DUO_API_HOSTNAME'),
            'client_id': os.getenv('DUO_CLIENT_ID'),
            'client_secret': os.getenv('DUO_CLIENT_SECRET'),
        },
        # Oracle Database: HRPD (PeopleSoft HR)
        'hr_db': {
            'username': os.getenv('HR_DB_USERNAME'),
            'password': os.getenv('HR_DB_PASSWORD'),
            'connect_string': os.getenv('HR_DB_CONNECT_STRING'),
            'timeout': _int_or_default(os.getenv('HR_DB_TIMEOUT'), DEFAULT_DB_TIMEOUT),
        },
        # Oracle Database: LSPD (PeopleSoft LS)
        'ls_db': {
            'username': os.getenv('LS_DB_USERNAME'),
            'password': os.getenv('LS_DB_PASSWORD'),
            'connect_string': os.getenv('LS_DB_CONNECT_STRING'),
            'timeout': _int_or_default(os.getenv('LS_DB_TIMEOUT'), DEFAULT_DB_TIMEOUT),
        },
        # SMTP
        'smtp': {
            'hostname': os.getenv('SMTP_HOSTNAME', DEFAULT_SMTP_HOST),
            'port': _int_or_default(os.getenv('SMTP_PORT'), DEFAULT_SMTP_PORT),
        },
        # Logging
        'logging': {
            'dir': os.getenv('LOG_DIR', str(DEFAULT_LOG_DIR)),
            'level': os.getenv('LOG_LEVEL', DEFAULT_LOG_LEVEL),
            'to_file': os.getenv('LOG_TO_FILE', 'true').lower() == 'true',
            'to_console': os.getenv('LOG_TO_CONSOLE', 'true').lower() == 'true',
            'colorize': os.getenv('LOG_COLORIZE_CONSOLE', 'false').lower() == 'true',
        },
    }

    # Legacy alias: config['edir'] → config['edir_prod']
    # Existing scripts that reference config['edir']['base_dn'] etc. keep working.
    config['edir'] = config['edir_prod']

    return config


# =============================================================================
# Domain Helpers
# =============================================================================

def get_domain_config(domain: str, config: dict[str, Any] | None = None) -> dict[str, Any]:
    """
    Get configuration for a specific AD domain.

    Args:
        domain: Domain name ('ad', 'hsc', 'students', 'unt')
        config: Optional pre-loaded config dict. If None, loads from .env.

    Returns:
        Dictionary with domain-specific configuration.

    Raises:
        ValueError: If domain is not valid.
    """
    domain_lower = domain.lower()
    if domain_lower not in VALID_AD_DOMAINS:
        raise ValueError(
            f"Invalid domain '{domain}'. "
            f"Must be one of: {', '.join(VALID_AD_DOMAINS)}"
        )

    if config is None:
        config = load_config()

    return config[f'ad_{domain_lower}']


def get_edir_config(
    environment: str,
    config: dict[str, Any] | None = None
) -> dict[str, Any]:
    """
    Get configuration for a specific eDirectory environment.

    Args:
        environment: Environment name ('test', 'prod').
        config: Optional pre-loaded config dict. If None, loads from .env.

    Returns:
        Dictionary with environment-specific eDirectory configuration.

    Raises:
        ValueError: If environment is not valid.
    """
    env_lower = environment.lower()
    if env_lower not in VALID_EDIR_ENVIRONMENTS:
        raise ValueError(
            f"Invalid eDirectory environment '{environment}'. "
            f"Must be one of: {', '.join(VALID_EDIR_ENVIRONMENTS)}"
        )

    if config is None:
        config = load_config()

    return config[f'edir_{env_lower}']


def get_dc_prefix_for_domain_dn(domain_dn: str) -> str | None:
    """
    Get the environment variable prefix for a domain based on its DN.

    Args:
        domain_dn: Domain distinguished name
                   (e.g., 'DC=unt,DC=ad,DC=unt,DC=edu')

    Returns:
        Environment variable prefix (e.g., 'AD_UNT') or None if not found.
    """
    domain_dn_lower = domain_dn.lower()

    for domain_suffix, prefix in DOMAIN_DC_MAPPING.items():
        if domain_dn_lower == domain_suffix.lower():
            return prefix

    return None


def extract_domain_from_dn(dn: str) -> str | None:
    """
    Extract the domain portion (DC components) from a distinguished name.

    Args:
        dn: Full DN (e.g., 'CN=User,OU=Users,DC=unt,DC=ad,DC=unt,DC=edu')

    Returns:
        Domain DN portion (e.g., 'DC=unt,DC=ad,DC=unt,DC=edu') or None.
    """
    parts = dn.split(',')
    dc_parts = [p.strip() for p in parts if p.strip().upper().startswith('DC=')]
    if dc_parts:
        return ','.join(dc_parts)
    return None
