# IAM Modules

Shared Python modules for UNT IAM scripts.  This is a standalone
repository designed to be symlinked into consuming repos.

## Architecture

```
/root/scripts/
├── iam_modules/                      ← THIS REPO
│   ├── .env                          ← single source of truth for secrets
│   ├── .env.example
│   ├── __init__.py
│   ├── config.py                     ← configuration + centralized constants
│   ├── connections.py                ← one-call connection functions (NEW)
│   ├── edir_client.py                ← eDirectory client class
│   ├── ad_client.py                  ← AD Domain Controller client class
│   ├── gc_client.py                  ← AD Global Catalog client class
│   ├── graph_client.py               ← Microsoft Graph API client class
│   ├── get_user_by_any_mail_or_id.py ← flexible eDir user lookup
│   ├── logging_utils.py              ← standardized logging → /var/log/iam
│   ├── cli_utils.py                  ← prompts, paged output, signals
│   └── idm_utils.py                  ← GUID conversion utilities
│
├── iam-provisioning-scripts/         ← consuming repo
│   ├── iam_modules -> ../iam_modules/
│   └── send_passwordexpirationnotice.py
│
└── iam-dstools/                      ← another consuming repo
    ├── iam_modules -> ../iam_modules/
    └── ...
```

## Setup

### 1. Clone this repo

```bash
cd /root/scripts
git clone <repo-url> iam_modules
```

### 2. Create the .env file

```bash
cd iam_modules
cp .env.example .env
# Edit .env with real credentials
```

### 3. Symlink from consuming repos

```bash
cd /root/scripts/iam-provisioning-scripts
ln -s ../iam_modules iam_modules
```

### 4. Install dependencies

```bash
pip install python-dotenv ldap3 requests
```

## Quick Start

Every script follows the same three-line pattern:

```python
from iam_modules import load_config, setup_logging
from iam_modules.connections import connect_to_edir

config = load_config(__file__)
logger = setup_logging('my_script')
conn   = connect_to_edir(config, 'prod', logger)
```

## Modules

| Module | Purpose |
|--------|---------|
| `config.py` | `.env` loading, centralized constants, domain helpers |
| `connections.py` | One-call functions: `connect_to_edir`, `connect_to_ad`, `connect_to_gc`, `connect_to_idtree` (legacy) |
| `edir_client.py` | `EDirectoryClient` class with full CRUD operations |
| `ad_client.py` | `ADDomainControllerClient` class (read/write per-domain) |
| `gc_client.py` | `ADGlobalCatalogClient` class (read-only forest-wide) |
| `graph_client.py` | `GraphAPIClient` class for Entra ID |
| `get_user_by_any_mail_or_id.py` | Flexible user lookup by mail/euid/workforceID |
| `logging_utils.py` | `setup_logging()` → `/var/log/iam` by default |
| `cli_utils.py` | `prompt_yes_no`, `paged_output`, `handle_interrupt` |
| `idm_utils.py` | `guid_to_association`, `association_to_guid` |

## Usage Patterns

### Pattern 1: Bare Connection (simplest — most scripts)

Use when you need direct `ldap3.Connection` access for custom
searches and modifications:

```python
from iam_modules import load_config, setup_logging
from iam_modules.connections import connect_to_edir

config = load_config(__file__)
logger = setup_logging('my_script')
conn   = connect_to_edir(config, 'prod', logger)
search_base = config['edir_prod']['base_dn']

conn.search(search_base, '(euid=jsmith)', SUBTREE, attributes=['mail'])
# ... work with conn.entries ...
conn.unbind()
```

### Pattern 2: Client Class (richer API)

Use when you want pre-built methods for common operations:

```python
from iam_modules import load_config, setup_logging
from iam_modules.edir_client import EDirectoryClient

config = load_config(__file__)
logger = setup_logging('my_script')

client = EDirectoryClient.from_config(config, logger, environment='prod')
if client.connect():
    user = client.find_user_by_uid('jsmith')
    client.modify_attribute(user['dn'], 'mail', 'new@unt.edu', dry_run=True)
    client.disconnect()
```

### Pattern 3: Multi-Domain AD

```python
from iam_modules.connections import connect_to_ad

for domain in ['unt', 'hsc', 'students']:
    conn = connect_to_ad(config, domain, logger)
    # ... operations ...
    conn.unbind()
```

### Pattern 4: Entra ID (Graph API)

```python
from iam_modules.graph_client import GraphAPIClient

client = GraphAPIClient.from_config(config, logger)
if client.authenticate():
    group = client.get_group_by_name('ECS-DUO-Users')
    members = client.get_group_members(group['id'])
```

### Centralized Constants

```python
from iam_modules import (
    DEFAULT_LOG_DIR,        # Path('/var/log/iam')
    DEFAULT_SMTP_HOST,      # 'localhost'
    DEFAULT_SMTP_PORT,      # 25
    EMAIL_FROM_AMS,         # 'AMS <password-expiration-notice@ams.untsystem.edu>'
    VALID_AD_DOMAINS,       # ['ad', 'hsc', 'students', 'unt']
)
```

### Application Settings from .env

```python
config = load_config(__file__)

smtp_host = config['smtp']['host']      # from SMTP_HOST or default
smtp_port = config['smtp']['port']      # from SMTP_PORT or default
vpn_dn    = config['app']['vpn_group_employee']  # from VPN_GROUP_EMPLOYEE
```

## .env Resolution

The `.env` file is found in this order:

1. The calling script's directory
2. The calling script's parent directory
3. **The real iam_modules directory** (resolves through symlinks)

This means the `.env` in *this* repo is the final fallback,
which is the expected location for production deployments.

## Changelog (v3.1.0)

- **NEW** `connect_to_edir(config, environment, logger)` — environment-aware eDirectory connections (`'test'` or `'prod'`)
- **NEW** `config['edir_test']` / `config['edir_prod']` sections in `load_config()` (env vars: `EDIR_TEST_*`, `EDIR_PROD_*`)
- **NEW** `EDIR_PROD_*` falls back to unprefixed `EDIR_*` for backward compatibility
- **NEW** `VALID_EDIR_ENVIRONMENTS` constant (`['test', 'prod']`)
- **NEW** `get_edir_config(environment, config)` helper in `config.py`
- **UPDATED** `EDirectoryClient.from_config()` accepts optional `environment` parameter
- **RETAINED** `connect_to_idtree()` as backward-compatible alias (delegates to `connect_to_edir(config, 'prod', logger)`)
- **RETAINED** `config['edir']` as alias for `config['edir_prod']`

## Changelog (v2.0.0)

- **NEW** `connections.py` — replaces 21+ inline `connect_to_idtree()` functions
- **FIXED** `edir_client.py` — added production TLS cipher string and `connect_timeout=600`
- **FIXED** `ad_client.py` / `gc_client.py` — added `connect_timeout`
- **FIXED** `graph_client.py` — removed duplicate `return False`
- **NEW** `from_config()` classmethod on all client classes
- **NEW** Centralized constants in `config.py` (SMTP, email, log dir, etc.)
- **NEW** `config['smtp']` and `config['app']` sections in `load_config()`
- **UPDATED** `.env` resolution is symlink-safe (resolves to real module path)
- **UPDATED** `logging_utils.py` defaults to `/var/log/iam`
- **UPDATED** `get_user_by_any_mail_or_id.py` uses shared connection infrastructure
- **UPDATED** `__init__.py` exports centralized constants
