"""
Microsoft Graph API Client for Entra ID operations.

Provides access to Microsoft Entra ID (Azure AD) via the Graph API for
user and group management operations.
"""

from __future__ import annotations

import logging
from typing import Any

from .config import EXCLUDED_ENTRA_DOMAINS

# Optional requests support
try:
    import requests  # noqa: F401
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


# Microsoft Graph API endpoints
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
GRAPH_AUTH_URL = "https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"


class GraphAPIClient:
    """
    Client for Microsoft Graph API operations.
    
    Provides methods for managing Entra ID users and groups using
    client credentials (app-only) authentication.
    
    Example:
        client = GraphAPIClient(
            tenant_id='your-tenant-id',
            client_id='your-client-id',
            client_secret='your-client-secret',
            logger=logger
        )
        
        if client.authenticate():
            group = client.get_group_by_name('MyGroup')
            members = client.get_group_members(group['id'])
    """
    
    def __init__(self, tenant_id: str, client_id: str, client_secret: str, 
                 logger: logging.Logger | None = None):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.logger = logger or logging.getLogger(__name__)
        self.access_token: str = ""
    
    @classmethod
    def from_config(cls, config: dict[str, Any],
                    logger: logging.Logger | None = None) -> 'GraphAPIClient':
        """
        Create a GraphAPIClient from a load_config() dict.

        Args:
            config: Configuration dict from load_config().
            logger: Optional logger instance.

        Returns:
            Configured (but not yet authenticated) GraphAPIClient.
        """
        entra = config['entra']
        return cls(
            tenant_id=entra['tenant_id'],
            client_id=entra['client_id'],
            client_secret=entra['client_secret'],
            logger=logger
        )
    
    def authenticate(self) -> bool:
        """
        Obtain an access token using client credentials flow.
        
        Returns:
            True if authentication successful, False otherwise
        """
        if not REQUESTS_AVAILABLE:
            self.logger.error("requests library not available. Install with: pip install requests")
            return False
        
        import requests
        
        auth_url = GRAPH_AUTH_URL.format(tenant_id=self.tenant_id)
        
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "https://graph.microsoft.com/.default",
            "grant_type": "client_credentials"
        }
        
        try:
            self.logger.debug(f"Authenticating to Entra ID tenant: {self.tenant_id}")
            response = requests.post(auth_url, data=data, timeout=30)
            response.raise_for_status()
            
            token_data = response.json()
            token = token_data.get("access_token")
            if not token:
                self.logger.error("No access token in response")
                return False
            self.access_token = token
            self.logger.debug("Successfully obtained access token")
            return True
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Authentication failed: {e}")
            return False
    
    def _headers(self) -> dict[str, str]:
        """Return headers for Graph API requests."""
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
    
    def _make_request(self, method: str, endpoint: str, 
                      json_data: dict[str, Any] | None = None) -> dict[str, Any] | None:
        """
        Make a request to the Graph API.
        
        Args:
            method: HTTP method (GET, POST, PATCH, DELETE)
            endpoint: API endpoint (without base URL)
            json_data: Optional JSON body for POST/PATCH requests
        
        Returns:
            Response JSON or None on error
        """
        import requests
        
        url = f"{GRAPH_BASE_URL}{endpoint}"
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._headers(),
                json=json_data,
                timeout=30
            )
            
            # Handle 204 No Content (successful delete/update)
            if response.status_code == 204:
                return {"success": True}
            
            # Handle errors
            if not response.ok:
                error_data = response.json() if response.text else {}
                error_msg = error_data.get("error", {}).get("message", response.text)
                self.logger.error(f"API request failed ({response.status_code}): {error_msg}")
                return None
            
            return response.json() if response.text else {"success": True}
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed: {e}")
            return None
    
    # -------------------------------------------------------------------------
    # User Operations
    # -------------------------------------------------------------------------
    
    def get_user_by_upn(self, upn: str) -> dict[str, Any] | None:
        """
        Get a user by their userPrincipalName.
        
        Note: Users in excluded domains (e.g., onmicrosoft.com) are rejected.
        
        Args:
            upn: User principal name
        
        Returns:
            User object dict or None if not found
        """
        if any(upn.lower().endswith(f"@{domain}") for domain in EXCLUDED_ENTRA_DOMAINS):
            self.logger.warning(f"Rejecting user from excluded domain: {upn}")
            return None
        
        self.logger.debug(f"Looking up user by UPN: {upn}")
        return self._make_request(
            "GET", 
            f"/users/{upn}?$select=id,userPrincipalName,displayName,employeeId,onPremisesSyncEnabled"
        )
    
    def get_user_by_employee_id(self, employee_id: str) -> dict[str, Any] | None:
        """
        Get a user by their employeeId.
        
        Note: Users in excluded domains are filtered out.
        
        Args:
            employee_id: Employee ID to search for
        
        Returns:
            User object dict or None if not found
        
        Raises:
            ValueError: If multiple users are found (multi-domain scenario)
                       Format: "MULTIPLE_USERS:employeeId:upn1|upn2|upn3"
        """
        self.logger.debug(f"Looking up user by employeeId: {employee_id}")
        
        filter_query = f"employeeId eq '{employee_id}'"
        endpoint = f"/users?$filter={filter_query}&$select=id,userPrincipalName,displayName,employeeId,onPremisesSyncEnabled"
        
        result = self._make_request("GET", endpoint)
        
        if result and result.get("value"):
            # Filter out users from excluded domains
            users = [
                u for u in result["value"]
                if not any(u.get("userPrincipalName", "").lower().endswith(f"@{domain}") 
                          for domain in EXCLUDED_ENTRA_DOMAINS)
            ]
            
            if len(users) == 1:
                return users[0]
            elif len(users) > 1:
                # Multiple users found - raise error with details (pipe delimiter)
                upn_list = [u.get("userPrincipalName") or "Unknown" for u in users]
                raise ValueError(f"MULTIPLE_USERS:{employee_id}:{'|'.join(upn_list)}")
        
        return None
    
    def resolve_user(self, identifier: str) -> dict[str, Any] | None:
        """
        Resolve a user by UPN or employeeId.
        
        If the identifier contains '@', treat it as a UPN.
        Otherwise, look up by employeeId.
        
        Args:
            identifier: UPN or employeeId
        
        Returns:
            User object dict or None if not found
        
        Raises:
            ValueError: If multiple users are found for an employeeId
        """
        identifier = identifier.strip()
        
        if "@" in identifier:
            user = self.get_user_by_upn(identifier)
        else:
            # This may raise ValueError if multiple users found
            user = self.get_user_by_employee_id(identifier)
        
        if user:
            self.logger.debug(f"Resolved '{identifier}' to user: {user.get('userPrincipalName')} (ID: {user.get('id')})")
        else:
            self.logger.warning(f"Could not resolve user: {identifier}")
        
        return user
    
    # -------------------------------------------------------------------------
    # Group Operations
    # -------------------------------------------------------------------------
    
    def get_group_by_name(self, display_name: str) -> dict[str, Any] | None:
        """
        Get a group by its display name.
        
        Args:
            display_name: Group display name
        
        Returns:
            Group object dict or None if not found
        """
        self.logger.debug(f"Looking up group: {display_name}")
        
        filter_query = f"displayName eq '{display_name}'"
        endpoint = f"/groups?$filter={filter_query}&$select=id,displayName,description,mailEnabled,securityEnabled,groupTypes,onPremisesSyncEnabled"
        
        result = self._make_request("GET", endpoint)
        
        if result and result.get("value"):
            groups = result["value"]
            if len(groups) == 1:
                return groups[0]
            elif len(groups) > 1:
                self.logger.warning(f"Multiple groups found with name '{display_name}', using first match")
                return groups[0]
        
        return None
    
    def get_group_by_id(self, group_id: str) -> dict[str, Any] | None:
        """
        Get a group by its ID.
        
        Args:
            group_id: Entra ID group ID
        
        Returns:
            Group object dict or None if not found
        """
        return self._make_request(
            "GET",
            f"/groups/{group_id}?$select=id,displayName,description,mailEnabled,securityEnabled,groupTypes,onPremisesSyncEnabled"
        )
    
    def create_group(self, display_name: str, description: str | None = None, 
                     dry_run: bool = False) -> dict[str, Any] | None:
        """
        Create a new security group.
        
        Args:
            display_name: Name for the new group
            description: Optional description
            dry_run: If True, return fake result without creating
        
        Returns:
            Created group object dict or None on error
        """
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would create group: {display_name}")
            return {"id": "dry-run-id", "displayName": display_name}
        
        self.logger.info(f"Creating group: {display_name}")
        
        group_data: dict[str, Any] = {
            "displayName": display_name,
            "mailEnabled": False,
            "mailNickname": display_name.replace(" ", "").lower(),
            "securityEnabled": True,
            "description": description or f"Security group: {display_name}"
        }
        
        return self._make_request("POST", "/groups", group_data)
    
    def delete_group(self, group_id: str, dry_run: bool = False) -> bool:
        """
        Delete a group by its ID.
        
        Args:
            group_id: Group ID to delete
            dry_run: If True, log but don't delete
        
        Returns:
            True if successful, False on error
        """
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would delete group ID: {group_id}")
            return True
        
        self.logger.info(f"Deleting group ID: {group_id}")
        result = self._make_request("DELETE", f"/groups/{group_id}")
        return result is not None
    
    def get_group_members(self, group_id: str) -> list[dict[str, Any]] | None:
        """
        Get all members of a group.
        
        Handles pagination for large groups.
        
        Args:
            group_id: Group ID
        
        Returns:
            List of member objects or None on error
        """
        self.logger.debug(f"Getting members for group ID: {group_id}")
        
        members: list[dict[str, Any]] = []
        endpoint: str | None = f"/groups/{group_id}/members?$select=id,userPrincipalName,displayName,employeeId"
        
        while endpoint:
            result = self._make_request("GET", endpoint)
            
            if result is None:
                return None
            
            members.extend(result.get("value", []))
            
            # Handle pagination
            next_link = result.get("@odata.nextLink")
            if next_link:
                endpoint = next_link.replace(GRAPH_BASE_URL, "")
            else:
                endpoint = None
        
        return members
    
    def add_group_member(self, group_id: str, user_id: str, dry_run: bool = False) -> bool:
        """
        Add a member to a group.
        
        Args:
            group_id: Group ID
            user_id: User ID to add
            dry_run: If True, log but don't add
        
        Returns:
            True if successful, False on error
        """
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would add user {user_id} to group {group_id}")
            return True
        
        self.logger.debug(f"Adding user {user_id} to group {group_id}")
        
        member_data: dict[str, Any] = {
            "@odata.id": f"{GRAPH_BASE_URL}/directoryObjects/{user_id}"
        }
        
        result = self._make_request("POST", f"/groups/{group_id}/members/$ref", member_data)
        return result is not None
    
    def remove_group_member(self, group_id: str, user_id: str, dry_run: bool = False) -> bool:
        """
        Remove a member from a group.
        
        Args:
            group_id: Group ID
            user_id: User ID to remove
            dry_run: If True, log but don't remove
        
        Returns:
            True if successful, False on error
        """
        if dry_run:
            self.logger.info(f"[DRY-RUN] Would remove user {user_id} from group {group_id}")
            return True
        
        self.logger.debug(f"Removing user {user_id} from group {group_id}")
        result = self._make_request("DELETE", f"/groups/{group_id}/members/{user_id}/$ref")
        return result is not None
    
    def is_synced_group(self, group: dict[str, Any]) -> bool:
        """
        Check if a group is synced from on-premises Active Directory.
        
        Args:
            group: Group object dict
        
        Returns:
            True if synced from on-prem, False otherwise
        """
        return group.get("onPremisesSyncEnabled") is True
