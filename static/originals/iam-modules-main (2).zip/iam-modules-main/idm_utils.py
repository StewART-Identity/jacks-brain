"""
Identity Management utilities for IAM scripts.

Provides GUID conversion and other IDM-related utility functions.
"""

from __future__ import annotations

import uuid


def guid_to_association(guid_str: str) -> str:
    """
    Convert a GUID string to an IDM association value.
    
    Replicates the PowerShell functionality:
    [System.BitConverter]::ToString([System.GUID]::Parse(guid).ToByteArray()).toLower() -replace '-'
    
    This is used to create association values that match how Microsoft's .NET
    framework serializes GUIDs to byte arrays (mixed-endian format).
    
    Args:
        guid_str: GUID string (with or without braces/hyphens)
    
    Returns:
        Lowercase hex string without dashes (32 characters)
    
    Example:
        >>> guid_to_association('{D23929BD-D8F7-4411-75A0-BCD5F535E61B}')
        'bd2939d2f7d81144a075bcd5f535e61b'
        
        >>> guid_to_association('D23929BD-D8F7-4411-75A0-BCD5F535E61B')
        'bd2939d2f7d81144a075bcd5f535e61b'
    """
    # Parse the GUID string
    guid_obj = uuid.UUID(guid_str)
    
    # Get bytes in network order
    network_bytes = guid_obj.bytes
    
    # Convert to .NET ToByteArray() format (mixed-endian)
    # GUID structure: Data1(4 bytes) + Data2(2 bytes) + Data3(2 bytes) + Data4(8 bytes)
    # Data1, Data2, Data3 are little-endian, Data4 is big-endian
    dotnet_bytes = bytearray(16)
    
    # Data1 (first 4 bytes) - reverse byte order
    dotnet_bytes[0:4] = network_bytes[3::-1]
    
    # Data2 (next 2 bytes) - reverse byte order  
    dotnet_bytes[4:6] = network_bytes[5:3:-1]
    
    # Data3 (next 2 bytes) - reverse byte order
    dotnet_bytes[6:8] = network_bytes[7:5:-1]
    
    # Data4 (last 8 bytes) - keep original order
    dotnet_bytes[8:16] = network_bytes[8:16]
    
    # Convert to lowercase hex string (without dashes)
    return dotnet_bytes.hex().lower()


def association_to_guid(association: str) -> str:
    """
    Convert an IDM association value back to a GUID string.
    
    This is the reverse of guid_to_association().
    
    Args:
        association: Lowercase hex string (32 characters)
    
    Returns:
        Standard GUID string with hyphens (e.g., 'D23929BD-D8F7-4411-75A0-BCD5F535E61B')
    
    Example:
        >>> association_to_guid('bd2939d2f7d81144a075bcd5f535e61b')
        'D23929BD-D8F7-4411-75A0-BCD5F535E61B'
    """
    # Convert hex string to bytes
    dotnet_bytes = bytes.fromhex(association)
    
    if len(dotnet_bytes) != 16:
        raise ValueError(f"Invalid association length: expected 32 hex chars, got {len(association)}")
    
    # Convert from .NET format back to standard GUID bytes
    network_bytes = bytearray(16)
    
    # Data1 (first 4 bytes) - reverse byte order
    network_bytes[0:4] = dotnet_bytes[3::-1]
    
    # Data2 (next 2 bytes) - reverse byte order
    network_bytes[4:6] = dotnet_bytes[5:3:-1]
    
    # Data3 (next 2 bytes) - reverse byte order
    network_bytes[6:8] = dotnet_bytes[7:5:-1]
    
    # Data4 (last 8 bytes) - keep original order
    network_bytes[8:16] = dotnet_bytes[8:16]
    
    # Create UUID from bytes and return string representation
    guid_obj = uuid.UUID(bytes=bytes(network_bytes))
    return str(guid_obj).upper()


def validate_guid(guid_str: str) -> bool:
    """
    Validate that a string is a properly formatted GUID.
    
    Args:
        guid_str: String to validate
    
    Returns:
        True if valid GUID format, False otherwise
    """
    try:
        uuid.UUID(guid_str)
        return True
    except (ValueError, AttributeError):
        return False


def normalize_guid(guid_str: str) -> str:
    """
    Normalize a GUID string to standard format (uppercase with hyphens, no braces).
    
    Args:
        guid_str: GUID string in any format
    
    Returns:
        Normalized GUID string (e.g., 'D23929BD-D8F7-4411-75A0-BCD5F535E61B')
    
    Raises:
        ValueError: If input is not a valid GUID
    """
    return str(uuid.UUID(guid_str)).upper()


def test_guid_conversion():
    """Test function to verify the GUID conversion works correctly."""
    test_cases = [
        '{D23929BD-D8F7-4411-75A0-BCD5F535E61B}',
        'D23929BD-D8F7-4411-75A0-BCD5F535E61B',
        'd23929bd-d8f7-4411-75a0-bcd5f535e61b'
    ]
    
    print("Testing GUID to Association conversion:")
    print("-" * 60)
    
    for test_guid in test_cases:
        association = guid_to_association(test_guid)
        back_to_guid = association_to_guid(association)
        normalized = normalize_guid(test_guid)
        
        print(f"Input GUID:    {test_guid}")
        print(f"Association:   {association}")
        print(f"Back to GUID:  {back_to_guid}")
        print(f"Round-trip OK: {back_to_guid == normalized}")
        print("-" * 60)


if __name__ == "__main__":
    test_guid_conversion()
