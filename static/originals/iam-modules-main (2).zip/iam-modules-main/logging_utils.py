"""
Logging utilities for IAM scripts.

Provides standardized logging setup with both file and console handlers.
Defaults to /var/log/iam if no log_dir is specified.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from .config import DEFAULT_LOG_DIR


def setup_logging(
    name: str,
    log_dir: Path | str | None = None,
    console_level: int = logging.INFO,
    file_level: int = logging.DEBUG,
    log_format: str | None = None,
    console_format: str | None = None
) -> logging.Logger:
    """
    Configure logging to both file and console.

    Args:
        name: Logger name (typically the script name without extension)
        log_dir: Directory for log files. Defaults to /var/log/iam.
        console_level: Minimum level for console output (default: INFO)
        file_level: Minimum level for file output (default: DEBUG)
        log_format: Format string for file handler
        console_format: Format string for console handler

    Returns:
        Configured Logger instance.

    Example::

        logger = setup_logging('send_passwordexpirationnotice')
        logger.info("Script started")
    """
    # Set up log directory
    if log_dir is None:
        log_dir = DEFAULT_LOG_DIR
    else:
        log_dir = Path(log_dir)

    log_dir.mkdir(exist_ok=True, parents=True)

    # Create log filename with date
    log_filename = f"{name}_{datetime.now().strftime('%Y%m%d')}.log"
    log_filepath = log_dir / log_filename

    # Get or create logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Avoid adding handlers multiple times
    if logger.handlers:
        return logger

    # Default formats
    if log_format is None:
        log_format = "%(asctime)s - %(levelname)s - %(message)s"
    if console_format is None:
        console_format = "%(levelname)s: %(message)s"

    # File handler - detailed logging
    file_handler = logging.FileHandler(log_filepath)
    file_handler.setLevel(file_level)
    file_formatter = logging.Formatter(log_format, datefmt="%Y-%m-%d %H:%M:%S")
    file_handler.setFormatter(file_formatter)

    # Console handler - info and above
    console_handler = logging.StreamHandler()
    console_handler.setLevel(console_level)
    console_formatter = logging.Formatter(console_format)
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    """
    Get an existing logger by name.

    Args:
        name: Logger name

    Returns:
        Logger instance (may not be configured if setup_logging wasn't called)
    """
    return logging.getLogger(name)
