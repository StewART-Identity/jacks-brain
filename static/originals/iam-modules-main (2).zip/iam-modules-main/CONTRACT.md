# IAM Modules Integration Contract

## Purpose

This document describes the architecture and conventions for UNT IAM provisioning scripts. It is intended to be provided as context to any assistant helping integrate, migrate, or create scripts within this infrastructure.

If you are an AI assistant reading this document, follow the patterns and conventions described here exactly. They are the product of deliberate architectural decisions and have been validated against production eDirectory, Active Directory, Entra ID, and Oracle database infrastructure serving 72,000+ users.

---

## Architecture Overview

### Repository Layout

The UNT IAM scripting infrastructure uses two repositories with a symlink relationship:

```
/usr/local/iamadm/scripts/
├── iam-modules/                        ← STANDALONE REPO (note: hyphen in repo name)
│   ├── .env                            ← single source of truth for all credentials
│   ├── .env.example
│   ├── CONTRACT.md                     ← THIS DOCUMENT
│   ├── __init__.py
│   ├── config.py
│   ├── connections.py
│   ├── edir_client.py
│   ├── ad_client.py
│   ├── gc_client.py
│   ├── graph_client.py
│   ├── get_user_by_any_mail_or_id.py
│   ├── logging_utils.py
│   ├── cli_utils.py
│   └── idm_utils.py
│
├── iam-scripts-provisioning/           ← CONSUMING REPO
│   ├── iam_modules -> ../iam-modules/  ← SYMLINK (note: underscore, not hyphen)
│   ├── lib/                            ← business logic (SQL, domain rules)
│   │   ├── hrpd.py                     ← HR database queries
│   │   └── lspd.py                     ← LS database queries
│   ├── idtree/                         ← eDirectory scripts
│   │   └── send_passwordexpirationnotice.py
│   ├── eis/                            ← EIS-related scripts
│   ├── etc/                            ← miscellaneous scripts
│   ├── groups/                         ← group management scripts
│   ├── purge/                          ← account purge scripts
│   └── test/                           ← test scripts
│
├── iam-scripts-utilities/              ← CONSUMING REPO
│   ├── iam_modules -> ../iam-modules/
│   ├── batch/                          ← batch/reporting scripts
│   ├── cron/                           ← scheduled scripts
│   ├── etc/                            ← connection tests, certs
│   ├── groups/                         ← AD/Entra group management
│   ├── lib/                            ← business logic (domain rules, workflow helpers)
│   ├── mail/                           ← mail attribute management
│   ├── users/                          ← user lifecycle (deactivate, reactivate, etc.)
│   └── scripts/                         ← repo tooling (build_menu, test_scripts)
│
├── iam-scripts-alma-v2/                ← CONSUMING REPO
│   ├── iam_modules -> ../iam-modules/
│   └── scripts/                        ← batch account lifecycle
│
├── iam-scripts-drip/                   ← CONSUMING REPO
│   ├── iam_modules -> ../iam-modules/
│   └── scripts/                        ← LDIF record drip import
```

### Key Architectural Rules

1. **The symlink MUST use an underscore** (`iam_modules`), not a hyphen, because Python cannot import module names containing hyphens. The target repo uses a hyphen (`iam-modules`) and that is fine.

2. **Scripts are always exactly one directory level below the repo root.** There are no nested subdirectories (no `idtree/dev/`, no `groups/archive/`). This is a firm convention.

3. **All authentication, configuration, and connection management goes through `iam_modules`.** No script should define its own `connect_to_edir()` or `connect_to_idtree()`, its own TLS configuration, its own logging setup, or its own `.env` loading. This is the entire point of the architecture.

4. **Business logic stays in `lib/`.** SQL queries, domain-specific rules, and data transformation logic belong in the consuming repo's `lib/` directory, not in `iam_modules`. The module gives you a connection; `lib/` knows what to do with it.

5. **The `.env` file lives in the `iam-modules` repo directory.** The config loader resolves through symlinks using `os.path.realpath()`, so it finds the `.env` in the real module directory regardless of where the script runs from.

---

## The sys.path Preamble

Because scripts live in subdirectories (`idtree/`, `eis/`, etc.) but `iam_modules` is symlinked at the repo root, every script needs a path preamble at the top. This is the EXACT preamble to use — do not vary it:

```python
import os
import sys
from pathlib import Path

_script_dir = Path(os.path.realpath(__file__)).parent
_repo_root = _script_dir.parent
if (_repo_root / 'iam_modules').exists():
    sys.path.insert(0, str(_repo_root))
```

This must appear BEFORE any `from iam_modules import ...` statements.

---

## Standard Script Template

Every provisioning script should follow this structure:

```python
#!/usr/local/iamadm/miniconda3/envs/scripts/bin/python
"""
[Script Name]

[Brief description of what this script does.]

Requirements:
    pip install ldap3 python-dotenv oracledb

Usage:
    python script_name.py                  (dry-run by default)
    python script_name.py --commit         (execute changes)
    python script_name.py --commit --verbose
"""

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
import os
import sys
from pathlib import Path

_script_dir = Path(os.path.realpath(__file__)).parent
_repo_root = _script_dir.parent
if (_repo_root / 'iam_modules').exists():
    sys.path.insert(0, str(_repo_root))

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
import argparse
import logging
from typing import Any

from iam_modules import load_config, setup_logging, set_operation, run, DEFAULT_LOG_DIR
from iam_modules.connections import connect_to_edir  # and/or connect_to_ad, connect_to_gc
# from iam_modules.connections import connect_to_hrdb, connect_to_lsdb

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SCRIPT_NAME = 'script_name_without_extension'

# ---------------------------------------------------------------------------
# Business logic functions go here
# ---------------------------------------------------------------------------

# ...

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='What this script does.',
        epilog='Default mode is DRY-RUN. Pass --commit to execute changes.'
    )
    parser.add_argument('--commit', action='store_true',
                        help='Execute changes (default is dry-run)')
    parser.add_argument('--verbose', action='store_true',
                        help='Enable verbose logging to console')
    return parser.parse_args()

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    args = parse_arguments()

    console_level = logging.INFO if args.verbose else logging.WARNING
    logger = setup_logging(SCRIPT_NAME, console_level=console_level)
    config = load_config(__file__)

    mode = "COMMIT" if args.commit else "DRY-RUN"
    logger.info(f"Starting {SCRIPT_NAME} in {mode} mode")

    if args.commit:
        print("\n*** COMMIT MODE — changes WILL be made ***\n")
    else:
        print("\n*** DRY-RUN MODE — no changes will be made (pass --commit to execute) ***\n")

    # Connect to whatever services this script needs
    set_operation('connecting to eDirectory')
    conn = connect_to_edir(config, 'prod', logger)
    search_base = config['edir_prod']['base_dn']

    try:
        set_operation('processing')
        # ... business logic (call set_operation() as you go) ...
        return 0

    except Exception as exc:
        logger.error(f"Script failed: {exc}", exc_info=True)
        return 1
    finally:
        conn.unbind()

if __name__ == '__main__':
    run(main)
```

---

## Mandatory Conventions

### 1. Default Is ALWAYS Dry-Run

Every script that modifies data (LDAP writes, email sends, group membership changes, account deletions, etc.) MUST default to dry-run mode. The flag to execute is `--commit`.

- Running `python script.py` → dry-run, no changes
- Running `python script.py --commit` → live execution

Never use `--dry-run` as the flag. The safe state is the default; the user opts INTO danger with `--commit`.

### 2. Every Script Has --help

Use `argparse` for all scripts. This gives `--help` for free. Include a description and an epilog that reminds the user about dry-run default behavior.

### 3. Shebang Line

```python
#!/usr/local/iamadm/miniconda3/envs/scripts/bin/python
```

This is the Miniconda environment on the production server.

### 4. Logging

Always use `setup_logging()` from `iam_modules`:

```python
from iam_modules import setup_logging, DEFAULT_LOG_DIR

logger = setup_logging('script_name')
```

This writes to `/var/log/iam/script_name_YYYYMMDD.log` by default, with DEBUG level to file and INFO/WARNING to console (controlled by `--verbose`).

### 5. Script Naming

Script filenames use the PowerShell verb taxonomy adapted for IAM:

- `send_` — sends notifications (email, etc.)
- `invoke_` — executes a provisioning workflow
- `sync_` — synchronizes data between systems
- `get_` — retrieves and displays information
- `repair_` — fixes inconsistencies
- `restore_` — restores accounts or data
- `clear_` — removes attributes or objects

### 6. Graceful Ctrl+C Handling

Pressing Ctrl+C must NEVER produce a Python traceback. The `SIGINT` handler is registered **automatically** when any script imports from `iam_modules` — no setup required. Scripts just call `set_operation()` to describe what they're doing:

```python
from iam_modules import load_config, setup_logging, set_operation

set_operation('connecting to eDirectory')
conn = connect_to_edir(config, 'prod', logger)

set_operation('searching for expiring passwords (5-day window)')
accounts = find_expiring_passwords(conn, search_base, ...)

for i, acct in enumerate(accounts, 1):
    set_operation(f'sending notice to {acct["euid"]} ({i}/{len(accounts)})')
    send_expiration_email(...)
```

When the user presses Ctrl+C, they see:

```
Interrupted during: sending notice to jsmith (47/518)
No further changes will be made.
```

Not a wall of Python traceback. This is non-negotiable. These scripts run in production and are operated by humans who need to know what happened, not debug stack frames.

Scripts that never call `set_operation()` still get clean interrupt handling — the default message is "Interrupted during: initializing".

The protection has two layers:
1. **Signal handler** (automatic on import) — catches Ctrl+C during Python code.
2. **`run()` wrapper** — catches `KeyboardInterrupt` that escapes the signal handler when Python is blocked inside C-level I/O (SSL socket reads, Oracle network calls, etc.).

Both layers read from the same `_current_operation` state, so the message is always accurate. Scripts MUST use `run(main)` as their entry point:

```python
if __name__ == '__main__':
    run(main)
```

---

## Connection Functions Reference

**All connections use `raise_exceptions=True`.** This means failed LDAP operations (modify, add, delete) raise `LDAPException` instead of returning a result code. Scripts MUST use `try/except`, not `conn.result` checks:

```python
# ✅ CORRECT — catch the exception
try:
    conn.modify(dn, {'description': [(MODIFY_REPLACE, ['new value'])]})
    logger.info(f"Updated {dn}")
except LDAPException as e:
    logger.error(f"Failed to update {dn}: {e}")

# ❌ WRONG — conn.modify() raises before this line executes
conn.modify(dn, {'description': [(MODIFY_REPLACE, ['new value'])]})
if conn.result['result'] == 0:    # never reached on failure
    logger.info("Updated")
else:
    logger.error("Failed")        # dead code
```

### connect_to_edir(config, environment, logger) → ldap3.Connection

Connects to an eDirectory environment with production-correct TLS. The `environment` parameter is one of: `'test'`, `'prod'`.

- TLSv1.2 pinned
- Cipher string: `HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5`
- Connect timeout: from `EDIR_{TEST|PROD}_TIMEOUT` in .env (default 600s)
- Auto-bind with raise_exceptions=True

```python
from iam_modules.connections import connect_to_edir

conn = connect_to_edir(config, 'prod', logger)
search_base = config['edir_prod']['base_dn']
conn.search(search_base, '(euid=jsmith)', SUBTREE, attributes=['mail', 'cn'])
# ... work with conn.entries ...
conn.unbind()
```

### connect_to_idtree(config, logger) → ldap3.Connection *(legacy alias)*

Delegates to `connect_to_edir(config, 'prod', logger)`. Existing scripts using this function continue to work without changes. New scripts should use `connect_to_edir()`.

```python
from iam_modules.connections import connect_to_idtree

conn = connect_to_idtree(config, logger)
search_base = config['edir']['base_dn']  # alias for config['edir_prod']
conn.unbind()
```

### connect_to_ad(config, domain, logger) → ldap3.Connection

Connects to an Active Directory Domain Controller. The `domain` parameter is one of: `'ad'`, `'hsc'`, `'students'`, `'unt'`. Each domain uses its own service account (see Service Account Attribute Requirements).

- Auto-bind with raise_exceptions=True
- TLS with certificate validation disabled (internal CAs)

```python
from iam_modules.connections import connect_to_ad

conn = connect_to_ad(config, 'unt', logger)
search_base = config['ad_unt']['base_dn']
# ... AD operations ...
conn.unbind()
```

### connect_to_gc(config, logger) → ldap3.Connection

Connects to the AD Global Catalog (port 3269, forest-wide read-only searches).

```python
from iam_modules.connections import connect_to_gc

conn = connect_to_gc(config, logger)
search_base = config['gc']['base_dn']
# ... forest-wide searches ...
conn.unbind()
```

### connect_to_hrdb(config, logger) → oracledb.Connection

Connects to the HRPD Oracle database (PeopleSoft HR).

```python
from iam_modules.connections import connect_to_hrdb

hr_conn = connect_to_hrdb(config, logger)
cursor = hr_conn.cursor()
cursor.execute("SELECT EMPLID, NAME FROM PS_EMPLOYEES WHERE STATUS = 'A'")
# ... process rows ...
cursor.close()
hr_conn.close()
```

### connect_to_lsdb(config, logger) → oracledb.Connection

Connects to the LSPD Oracle database (PeopleSoft LS).

```python
from iam_modules.connections import connect_to_lsdb

ls_conn = connect_to_lsdb(config, logger)
cursor = ls_conn.cursor()
# ... queries ...
cursor.close()
ls_conn.close()
```

### Database Architecture Note

The `connect_to_hrdb()` and `connect_to_lsdb()` functions give you a raw `oracledb.Connection`. The SQL queries and business logic for these databases live in the consuming repo's `lib/` directory (e.g., `lib/hrpd.py`, `lib/lspd.py`), NOT in `iam_modules`. The module handles the connection; the lib handles the data.

```python
# CORRECT layering:
from iam_modules.connections import connect_to_hrdb
from lib.hrpd import get_active_employees

hr_conn = connect_to_hrdb(config, logger)
employees = get_active_employees(hr_conn)
hr_conn.close()
```

---

## Client Classes (Richer API)

For scripts that need higher-level operations (group membership management, user resolution, attribute modification with dry-run support), use the client classes instead of bare connections. All clients have a `from_config()` classmethod.

### EDirectoryClient

```python
from iam_modules.edir_client import EDirectoryClient

# New: explicit environment
client = EDirectoryClient.from_config(config, logger, environment='prod')

# Legacy: reads from config['edir'] (backward compatible)
client = EDirectoryClient.from_config(config, logger)

if client.connect():
    user = client.find_user_by_uid('jsmith')
    client.find_user_by_workforce_id('10012345')
    client.find_user_by_email('jsmith@unt.edu')
    client.modify_attribute(user['dn'], 'mail', 'new@unt.edu', dry_run=not args.commit)
    client.disconnect()
```

### ADDomainControllerClient

```python
from iam_modules.ad_client import ADDomainControllerClient

client = ADDomainControllerClient.from_config(config, 'unt', logger)
if client.connect():
    client.add_group_member(group_dn, user_dn, dry_run=not args.commit)
    client.remove_group_member(group_dn, user_dn, dry_run=not args.commit)
    client.disconnect()
```

### ADGlobalCatalogClient

```python
from iam_modules.gc_client import ADGlobalCatalogClient

client = ADGlobalCatalogClient.from_config(config, logger)
if client.connect():
    group_dn = client.find_group('ECS-DUO-Users')
    user = client.find_user_by_upn('jsmith@unt.edu')
    users = client.find_user_by_employee_id('10012345')
    members = client.get_group_members(group_dn)
    client.disconnect()
```

### GraphAPIClient (Entra ID)

```python
from iam_modules.graph_client import GraphAPIClient

client = GraphAPIClient.from_config(config, logger)
if client.authenticate():
    group = client.get_group_by_name('MyGroup')
    members = client.get_group_members(group['id'])
    client.add_group_member(group['id'], user['id'], dry_run=not args.commit)
```

---

## Configuration Reference

`load_config(__file__)` returns a dict with these sections:

| Key | Source | Contents |
|-----|--------|----------|
| `config['edir']` | Alias for `config['edir_prod']` | Legacy alias — existing scripts keep working |
| `config['edir_test']` | `EDIR_TEST_*` env vars | eDirectory test: `hostname`, `port`, `use_ssl`, `username`, `password`, `base_dn`, `timeout` |
| `config['edir_prod']` | `EDIR_PROD_*` → `EDIR_*` fallback | eDirectory production: same keys as edir_test |
| `config['gc']` | `AD_GC_*` env vars | `hostname`, `port`, `use_ssl`, `username`, `password`, `base_dn`, `domain`, `timeout` |
| `config['ad_ad']` | `AD_AD_*` env vars | AD forest root domain — same keys as gc |
| `config['ad_hsc']` | `AD_HSC_*` env vars | HSC domain connection |
| `config['ad_students']` | `AD_STUDENTS_*` env vars | Students domain connection |
| `config['ad_unt']` | `AD_UNT_*` env vars | UNT domain connection |
| `config['entra']` | `ENTRA_*` env vars | `tenant_id`, `client_id`, `client_secret` |
| `config['duo']` | `DUO_*` env vars | `api_hostname`, `client_id`, `client_secret` |
| `config['hr_db']` | `HR_DB_*` env vars | `username`, `password`, `connect_string`, `timeout` |
| `config['ls_db']` | `LS_DB_*` env vars | `username`, `password`, `connect_string`, `timeout` |
| `config['smtp']` | `SMTP_*` env vars | `hostname` (default: `localhost`), `port` (default: `25`) |
| `config['logging']` | `LOG_*` env vars | `dir`, `level`, `to_file`, `to_console`, `colorize` |

**Note:** Application-specific variables (`BATCH_*`, `DEACTIVATE_*`, `REACTIVATE_*`, `VPN_*`, etc.) are NOT loaded by `load_config()`. They are owned by the scripts that use them. Since `load_config()` calls `load_dotenv()`, scripts can read them via `os.getenv()` after calling `load_config()`.

### Centralized Constants

These are importable directly from `iam_modules`:

```python
from iam_modules import (
    DEFAULT_LOG_DIR,            # Path('/var/log/iam')
    DEFAULT_SMTP_HOST,          # 'localhost'
    DEFAULT_SMTP_PORT,          # 25
    VALID_AD_DOMAINS,           # ['ad', 'hsc', 'students', 'unt']
    VALID_EDIR_ENVIRONMENTS,    # ['test', 'prod']
    DOMAIN_DC_MAPPING,          # DN-to-prefix mapping for AD domains
    EXCLUDED_ENTRA_DOMAINS,     # ['myunt.onmicrosoft.com', 'myunttest.onmicrosoft.com']
    DEFAULT_EDIR_TIMEOUT,       # 600
    DEFAULT_AD_TIMEOUT,         # 30
    DEFAULT_GC_TIMEOUT,         # 30
    DEFAULT_DB_TIMEOUT,         # 30
)
```

---

## Migration Patterns

When converting an existing script to use `iam_modules`, here are the specific patterns to find and replace.

### Pattern A: Inline eDirectory Connection (21+ scripts do this)

**BEFORE (delete all of this):**
```python
import ssl
from dotenv import load_dotenv
from ldap3 import Server, Connection, ALL, Tls, SUBTREE

load_dotenv(Path(__file__).parent.parent / '.env')

EDIR_SERVER = os.getenv('EDIR_SERVER')
EDIR_PORT = int(os.getenv('EDIR_PORT', 637))
# ... more getenv calls ...

tls_config = Tls(
    validate=ssl.CERT_NONE,
    version=ssl.PROTOCOL_TLSv1_2,
    ciphers='HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5'
)
server = Server(EDIR_SERVER, port=EDIR_PORT, use_ssl=True, tls=tls_config, ...)
conn = Connection(server, user=EDIR_USERNAME, password=EDIR_PASSWORD, auto_bind=True)
```

**AFTER (replace with):**
```python
from iam_modules import load_config, setup_logging
from iam_modules.connections import connect_to_edir

config = load_config(__file__)
logger = setup_logging('script_name')
conn = connect_to_edir(config, 'prod', logger)
search_base = config['edir_prod']['base_dn']
```

> **Note:** Existing scripts using `connect_to_idtree(config, logger)` with `config['edir']` still work — no urgent migration needed.

### Pattern B: Inline Logging Setup (18+ scripts do this)

**BEFORE (delete):**
```python
import logging
from datetime import datetime

log_dir = Path('/var/log/iam')
log_file = log_dir / f'scriptname_{datetime.now():%Y%m%d}.log'
logger = logging.getLogger('scriptname')
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler(log_file)
# ... handler setup ...
```

**AFTER (replace with):**
```python
from iam_modules import setup_logging

logger = setup_logging('script_name')
```

### Pattern C: Inline AD Connection

**BEFORE (delete):**
```python
ad_server = os.getenv('AD_UNT_SERVER')
ad_port = int(os.getenv('AD_UNT_PORT', 636))
# ... manual TLS and connection setup ...
```

**AFTER (replace with):**
```python
from iam_modules.connections import connect_to_ad

conn = connect_to_ad(config, 'unt', logger)
search_base = config['ad_unt']['base_dn']
```

### Pattern D: Custom LDAPConnectionManager (4 scripts do this)

Some scripts (invoke_emailprovisioning.py, repair_idmassociation.py, restore_account.py, sync_userdata.py) define their own `LDAPConnectionManager` class that manages connections to multiple AD domains. Replace with a simple dict:

```python
from iam_modules.connections import connect_to_ad

ad_connections = {}
for domain in ['ad', 'hsc', 'students', 'unt']:
    ad_connections[domain] = connect_to_ad(config, domain, logger)

# Use:
conn = ad_connections['unt']
conn.search(config['ad_unt']['base_dn'], filter, SUBTREE, attributes=attrs)

# Cleanup:
for conn in ad_connections.values():
    conn.unbind()
```

### Pattern E: Hardcoded SMTP Settings

**BEFORE:**
```python
SMTP_HOST = 'localhost'
SMTP_PORT = 25
FROM_ADDRESS = 'AMS <password-expiration-notice@ams.untsystem.edu>'
```

**AFTER:**
```python
# SMTP connection comes from config:
smtp_host = config['smtp']['hostname']
smtp_port = config['smtp']['port']

# Email sender address is application-specific — define it in the script:
FROM_ADDRESS = 'AMS <password-expiration-notice@ams.untsystem.edu>'
```

### Pattern F: Inline Oracle Database Connection

**BEFORE (delete):**
```python
import cx_Oracle  # or oracledb

load_dotenv(...)
hr_user = os.getenv('HR_DB_USERNAME')
hr_pass = os.getenv('HR_DB_PASSWORD')
hr_dsn  = os.getenv('HR_DB_CONNECTSTRING')
hr_conn = cx_Oracle.connect(hr_user, hr_pass, hr_dsn)
```

**AFTER (replace with):**
```python
from iam_modules.connections import connect_to_hrdb

hr_conn = connect_to_hrdb(config, logger)
```

The SQL and business logic that uses the connection stays in `lib/hrpd.py` — only the connection setup moves to `iam_modules`.

---

## Checklist for Migrating a Script

When integrating an existing script, follow these steps in order:

- [ ] Add the sys.path preamble (copy it exactly from this document)
- [ ] Replace `.env` loading with `config = load_config(__file__)`
- [ ] Replace logging setup with `logger = setup_logging('script_name')`
- [ ] Replace LDAP connection code with the appropriate `connect_to_*()` function
- [ ] Replace Oracle connection code with `connect_to_hrdb()` or `connect_to_lsdb()`
- [ ] Replace hardcoded SMTP, email, and log directory constants with `iam_modules` imports
- [ ] Replace `--dry-run` flag (if present) with `--commit` flag; default must be dry-run
- [ ] Ensure `argparse` is used (provides `--help` automatically)
- [ ] Ensure the shebang line is `#!/usr/local/iamadm/miniconda3/envs/scripts/bin/python`
- [ ] Remove all `import ssl`, direct `Tls()` construction, and `load_dotenv()` calls
- [ ] Remove any `import cx_Oracle` and replace with `from iam_modules.connections import ...`
- [ ] Remove any `connect_to_idtree()` or `connect_to_edir()` function definition within the script
- [ ] Remove any `LDAPConnectionManager` class definition within the script
- [ ] Add `set_operation()` calls at each processing phase (Ctrl+C handler is automatic)
- [ ] Replace any `conn.result['result']` checks with `try/except LDAPException` (connections use `raise_exceptions=True`)
- [ ] Use `run(main)` as the entry point (not `sys.exit(main())`)
- [ ] Test with `python script_name.py --verbose` (dry-run) before committing

---

## Environment Details

- **Server:** iam-script-gab (production IAM scripting host)
- **Python:** Miniconda3 environment at `/usr/local/iamadm/miniconda3/envs/scripts/`
- **User:** `iamadm` (group: `iamteam`)
- **Log directory:** `/var/log/iam/`
- **Dependencies:** `ldap3`, `python-dotenv`, `requests`, `oracledb`, `psycopg2-binary`
- **eDirectory server:** `idmpidv01.untsystem.edu:637` (SSL, TLSv1.2 only)
- **AD domains:** `ad.unt.edu`, `hsc.ad.unt.edu`, `students.ad.unt.edu`, `unt.ad.unt.edu`
- **Global Catalog:** Port 3269 on `dcpd-ad-pri-01.ad.unt.edu`
- **Oracle HR (HRPD):** `oradb404.its.unt.edu:1521/hrpd.its.unt.edu`
- **Oracle LS (LSPD):** `oradb405.its.unt.edu:1521/lspd.its.unt.edu`

---

## What NOT to Do

1. **Do not define TLS configuration in any script.** It belongs in `connections.py` and `edir_client.py` only.
2. **Do not call `load_dotenv()` directly.** Use `load_config(__file__)`.
3. **Do not hardcode server names, ports, or credentials.** They come from the `.env` via `config`.
4. **Do not default to live mode.** The default is ALWAYS dry-run. The user opts in with `--commit`.
5. **Do not create subdirectories inside the category directories.** Scripts are one level deep, period.
6. **Do not use `--dry-run` as a flag.** The flag is `--commit`. Absence of `--commit` means dry-run.
7. **Do not import from `iam-modules`** (hyphen). The import is always `from iam_modules` (underscore). The symlink handles the translation.
8. **Do not use `cx_Oracle`.** Use `oracledb`. It is the official successor library.
9. **Do not put SQL queries or database business logic in `iam_modules`.** Connections go in the module; queries and business logic go in `lib/` in the consuming repo.
10. **Do not put database business logic in the scripts themselves.** It goes in `lib/hrpd.py`, `lib/lspd.py`, etc., so multiple scripts can share it.
11. **Do not allow Python tracebacks on Ctrl+C.** Use `run(main)` as the entry point and call `set_operation()` throughout. See Convention 6.
12. **Do not use `sys.exit(main())` as the entry point.** Use `run(main)` — it wraps the call with `KeyboardInterrupt` protection.
13. **Do not put application-specific environment variables in `iam_modules` config.** Variables like `BATCH_*`, `DEACTIVATE_*`, `REACTIVATE_*`, `VPN_*` are owned by the scripts that use them. Read them via `os.getenv()` after `load_config()` has loaded the `.env`.
14. **Do not use old env var names.** `*_SERVER` is now `*_HOSTNAME`. `HRDB_*` is now `HR_DB_*`. `LSDB_*` is now `LS_DB_*`. `HR_DB_CONNECTSTRING` is now `HR_DB_CONNECT_STRING`. `SMTP_HOST` is now `SMTP_HOSTNAME`. See `.env.example` for the canonical names.
15. **Do not check `conn.result['result']` after LDAP writes.** All `iam_modules` connections use `raise_exceptions=True`. Failed operations raise `LDAPException` — they never return a result code. Use `try/except LDAPException`. See Connection Functions Reference for the correct pattern.

---

## Service Account Attribute Requirements

This section documents every LDAP attribute that IAM scripts **write** to, organized by directory and domain. Use this as the authoritative reference when configuring service account permissions. **If you add a script that writes to a new attribute, update this section.**

The goal is least-privilege: the service accounts should have write access only to the attributes listed here, on the object classes specified. Read access to all standard attributes is assumed.

### Active Directory — Per-Domain Service Accounts

Each AD domain has its own service account. All required access should be granted via delegated permissions on the specific attributes and object types listed below — **none of these accounts need membership in Domain Admins, Enterprise Admins, or any other built-in admin group.**

| Domain | Service Account DN |
|--------|--------------------|
| AD (forest root + GC) | `CN=IAMScriptAD,OU=IAM,OU=Services,DC=ad,DC=unt,DC=edu` |
| UNT | `CN=IAMScriptUNT,OU=IAM,OU=Services,DC=unt,DC=ad,DC=unt,DC=edu` |
| HSC | `CN=IAMScriptHSC,OU=IAM,OU=Services,DC=hsc,DC=ad,DC=unt,DC=edu` |
| STUDENTS | `CN=IAMScriptSTU,OU=IAM,OU=Services,DC=students,DC=ad,DC=unt,DC=edu` |

#### Forest Root — IAMScriptAD (DC=ad,DC=unt,DC=edu)

| Attribute | Object Type | Operation | Scripts |
|-----------|-------------|-----------|---------|
| `member` | Group | Add/Delete | deactivate\_terminateduser, reactivate\_terminateduser |

The Global Catalog (port 3269) is **read-only** — no write delegation needed.

#### UNT — IAMScriptUNT (DC=unt,DC=ad,DC=unt,DC=edu)

| Attribute | Object Type | Operation | Scripts |
|-----------|-------------|-----------|---------|
| `description` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser |
| `employeeNumber` | User | Replace | repair\_useridmassns |
| `extensionAttribute15` | User, Group | Add/Replace | copy\_entrauser, sync\_adonpremobject, set\_entraextattribute |
| `gidNumber` | User, Group | Replace | sync\_usergidnumber |
| `member` | Group | Add/Delete | deactivate\_terminateduser, reactivate\_terminateduser, manage\_vpngroupmembers |
| `userAccountControl` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser |

#### HSC — IAMScriptHSC (DC=hsc,DC=ad,DC=unt,DC=edu)

| Attribute | Object Type | Operation | Scripts |
|-----------|-------------|-----------|---------|
| `description` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser |
| `employeeNumber` | User | Replace | repair\_useridmassns |
| `extensionAttribute15` | User, Group | Add/Replace | copy\_entrauser, sync\_adonpremobject, set\_entraextattribute |
| `gidNumber` | User, Group | Replace | sync\_usergidnumber |
| `member` | Group | Add/Delete | deactivate\_terminateduser, reactivate\_terminateduser |
| `userAccountControl` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser |

#### STUDENTS — IAMScriptSTU (DC=students,DC=ad,DC=unt,DC=edu)

| Attribute | Object Type | Operation | Scripts |
|-----------|-------------|-----------|---------|
| `description` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser (with `--students`) |
| `employeeNumber` | User | Replace | repair\_useridmassns |
| `extensionAttribute15` | User, Group | Add/Replace | copy\_entrauser, sync\_adonpremobject, set\_entraextattribute |
| `gidNumber` | User, Group | Replace | sync\_usergidnumber |
| `member` | Group | Add/Delete | deactivate\_terminateduser, reactivate\_terminateduser (with `--students`) |
| `userAccountControl` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser (with `--students`) |

Note: STUDENTS domain is skipped by default in deactivate\_terminateduser and reactivate\_terminateduser. The `--students` flag must be passed explicitly.

#### AD Scripts That Are Read-Only

These scripts connect to AD but perform **no writes** — they only need search/read access:

- compare\_adtoentragroup.py — reads group members
- count\_groupmembers.py — reads group member count
- get\_aduser.py — reads user attributes
- get\_groupmember.py — reads group members
- get\_uachieveinfo.py — reads user entitlements
- start\_idmsyncuserevent.py — reads AD to verify; writes only to eDirectory
- sync\_idmusermailattrs.py — reads AD associations; writes only to eDirectory

### eDirectory — IAMScript / IAMDrip

**Account DNs:**
- `cn=IAMScript,ou=IAMApplications,o=unt` (general scripts)
- `cn=IAMDrip,ou=IAMApplications,o=unt` (LDIF import tool)

#### Write Attributes

| Attribute | Object Type | Operation | Scripts |
|-----------|-------------|-----------|---------|
| `amspin` | User | Replace | manage\_amsuser |
| `description` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser |
| `DirXML-Associations` | User | Add/Delete/Replace | sync\_idmusermailattrs, start\_idmsyncuserevent, repair\_useridmassns |
| `employeeMail` | User | Replace | sync\_mailattr |
| `groupMembership` | User | Add/Delete | deactivate\_terminateduser, reactivate\_terminateduser |
| `loginDisabled` | User | Replace | deactivate\_terminateduser, reactivate\_terminateduser |
| `mail` | User | Replace | set\_usermailattrs, sync\_mailattr |
| `msxmail` | User | Replace | sync\_mailattr |
| `msxmailhsc` | User | Replace | sync\_mailattr |
| `objectClass` | User | Add (mailProperties) | sync\_mailattr |
| `prefmail` | User | Replace | set\_usermailattrs, sync\_mailattr |
| `studentMail` | User | Replace | sync\_mailattr |
| `systemaccess` | User | Add/Replace | manage\_amsuser |
| `untAccountHistory` | User | Add | deactivate\_terminateduser, reactivate\_terminateduser |
| `untAccountMove` | User | Replace | move\_users (cron) |
| `untsecretanswer` | User | Delete | manage\_amsuser |
| `untsecretquestion` | User | Delete | manage\_amsuser |

The IAMDrip service account (used by drip\_ldifrecords.py) requires write access to **arbitrary attributes** on user objects, as it replays LDIF records that may touch any attribute. This account should be scoped to `ou=people,o=unt` only.

#### eDirectory Scripts That Are Read-Only

These scripts connect to eDirectory but perform **no writes**:

- batch/export\_vpndata.py
- batch/find\_nonuntemailaddress.py
- batch/test\_logindisabled.py
- cron/update\_uachieveusers.py (reads eDir; writes to u.achieve)
- mail/get\_mailaddress.py
- mail/get\_usermailattrs.py
- users/get\_ediruser.py
- users/get\_nonstudents.py
- users/get\_userattributes.py
- users/search\_euid.py
- users/search\_untdeptattribute.py

### Maintaining This Section

When adding a new script or modifying an existing one to write to a new attribute:

1. Add the attribute to the appropriate table above.
2. Include the object type (User, Group, or both).
3. List the operation (Add, Delete, Replace).
4. Name the script(s) that perform the write.
5. If a new AD domain delegation is needed, update the delegation script (`delegate_iamscriptad.ps1`) and run it on the affected domain controller(s).

