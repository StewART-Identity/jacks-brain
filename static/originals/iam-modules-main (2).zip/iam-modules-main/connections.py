"""
Connection Convenience Functions.

Provides one-call functions to get connected, ready-to-use connections
from a config dict.  Covers LDAP (eDirectory, Active Directory) and
Oracle databases (HRPD, LSPD).

These replace the per-script connection helpers that were copy-pasted
across 21+ scripts.

Usage::

    from iam_modules import load_config, setup_logging
    from iam_modules.connections import connect_to_edir, connect_to_ad, connect_to_hrdb

    config = load_config(__file__)
    logger = setup_logging('my_script')

    edir_conn = connect_to_edir(config, 'prod', logger)
    ad_conn   = connect_to_ad(config, 'hsc', logger)
    hr_conn   = connect_to_hrdb(config, logger)

    # ... use connections ...

    edir_conn.unbind()
    ad_conn.unbind()
    hr_conn.close()

Legacy alias ``connect_to_idtree()`` is retained for backward compatibility
and reads from the unprefixed ``EDIR_*`` config section.
"""

from __future__ import annotations

import logging
from typing import Any

from ldap3 import Server, Connection, ALL

from .tls import edir_tls, ad_tls


# =============================================================================
# eDirectory (IDTREE)
# =============================================================================

def connect_to_edir(
    config: dict[str, Any],
    environment: str,
    logger: logging.Logger
) -> Connection:
    """
    Connect to an eDirectory environment and return a bound Connection.

    Args:
        config: Configuration dict from ``load_config()``.
        environment: Environment name ('test', 'prod').
        logger: Logger instance.

    Returns:
        A bound ``ldap3.Connection`` ready for search/modify.

    Raises:
        ldap3.core.exceptions.LDAPException: On connection failure.
        ValueError: If environment is invalid or config keys are missing.
    """
    from .config import VALID_EDIR_ENVIRONMENTS

    env_lower = environment.lower()
    if env_lower not in VALID_EDIR_ENVIRONMENTS:
        raise ValueError(
            f"Invalid eDirectory environment '{environment}'. "
            f"Must be one of: {', '.join(VALID_EDIR_ENVIRONMENTS)}"
        )

    edir = config[f'edir_{env_lower}']
    _validate_keys(edir, ['hostname', 'username', 'password', 'base_dn'],
                   f'edir_{env_lower}')

    timeout = edir.get('timeout', 600)

    server = Server(
        edir['hostname'],
        port=edir['port'],
        use_ssl=edir['use_ssl'],
        tls=edir_tls(),
        get_info=ALL,
        connect_timeout=timeout
    )

    conn = Connection(
        server,
        user=edir['username'],
        password=edir['password'],
        auto_bind=True,
        raise_exceptions=True
    )

    logger.info(
        f"Connected to eDirectory ({env_lower}): "
        f"{edir['hostname']}:{edir['port']}"
    )
    return conn


def connect_to_idtree(
    config: dict[str, Any],
    logger: logging.Logger
) -> Connection:
    """
    Connect to IDTREE (eDirectory production) and return a bound Connection.

    Backward-compatible alias for ``connect_to_edir(config, 'prod', logger)``.
    New scripts should use :func:`connect_to_edir` with an explicit environment.

    Args:
        config: Configuration dict from ``load_config()``.
        logger: Logger instance.

    Returns:
        A bound ``ldap3.Connection`` ready for search/modify.

    Raises:
        ldap3.core.exceptions.LDAPException: On connection failure.
        ValueError: If required config keys are missing.
    """
    return connect_to_edir(config, 'prod', logger)


# =============================================================================
# Active Directory (Domain Controller)
# =============================================================================

def connect_to_ad(
    config: dict[str, Any],
    domain: str,
    logger: logging.Logger
) -> Connection:
    """
    Connect to an Active Directory Domain Controller and return a bound Connection.

    Args:
        config: Configuration dict from ``load_config()``.
        domain: Domain short name ('ad', 'hsc', 'students', 'unt').
        logger: Logger instance.

    Returns:
        A bound ``ldap3.Connection`` ready for search/modify.

    Raises:
        ldap3.core.exceptions.LDAPException: On connection failure.
        ValueError: If domain is invalid or config keys are missing.
    """
    from .config import VALID_AD_DOMAINS

    domain_lower = domain.lower()
    if domain_lower not in VALID_AD_DOMAINS:
        raise ValueError(
            f"Invalid domain '{domain}'. "
            f"Must be one of: {', '.join(VALID_AD_DOMAINS)}"
        )

    ad_cfg = config[f'ad_{domain_lower}']
    _validate_keys(ad_cfg, ['hostname', 'username', 'password', 'base_dn'],
                   f'ad_{domain_lower}')

    timeout = ad_cfg.get('timeout', 30)

    server = Server(
        ad_cfg['hostname'],
        port=ad_cfg['port'],
        use_ssl=ad_cfg['use_ssl'],
        tls=ad_tls(),
        get_info=ALL,
        connect_timeout=timeout
    )

    conn = Connection(
        server,
        user=ad_cfg['username'],
        password=ad_cfg['password'],
        auto_bind=True,
        raise_exceptions=True
    )

    logger.info(
        f"Connected to AD domain '{domain_lower}': "
        f"{ad_cfg['hostname']}:{ad_cfg['port']}"
    )
    return conn


# =============================================================================
# Active Directory (Global Catalog)
# =============================================================================

def connect_to_gc(
    config: dict[str, Any],
    logger: logging.Logger
) -> Connection:
    """
    Connect to the AD Global Catalog and return a bound Connection.

    The Global Catalog provides read-only forest-wide searches on
    port 3269 (SSL).

    Args:
        config: Configuration dict from ``load_config()``.
        logger: Logger instance.

    Returns:
        A bound ``ldap3.Connection`` (read-only forest-wide searches).

    Raises:
        ldap3.core.exceptions.LDAPException: On connection failure.
        ValueError: If required config keys are missing.
    """
    gc_cfg = config['gc']
    _validate_keys(gc_cfg, ['hostname', 'username', 'password', 'base_dn'], 'gc')

    timeout = gc_cfg.get('timeout', 30)

    server = Server(
        gc_cfg['hostname'],
        port=gc_cfg['port'],
        use_ssl=gc_cfg['use_ssl'],
        tls=ad_tls(),
        get_info=ALL,
        connect_timeout=timeout
    )

    conn = Connection(
        server,
        user=gc_cfg['username'],
        password=gc_cfg['password'],
        auto_bind=True,
        raise_exceptions=True
    )

    logger.info(
        f"Connected to AD Global Catalog: "
        f"{gc_cfg['hostname']}:{gc_cfg['port']}"
    )
    return conn


# =============================================================================
# Oracle Database: HRPD (PeopleSoft HR)
# =============================================================================

def connect_to_hrdb(
    config: dict[str, Any],
    logger: logging.Logger
):
    """
    Connect to the HRPD Oracle database and return a connection.

    Uses the ``oracledb`` library (thin or thick mode, depending on
    client library availability).

    Args:
        config: Configuration dict from ``load_config()``.
        logger: Logger instance.

    Returns:
        An ``oracledb.Connection`` ready for queries.

    Raises:
        oracledb.Error: On connection failure.
        ValueError: If required config keys are missing.
    """
    return _connect_to_oracle(config, 'hr_db', 'HRPD', logger)


# =============================================================================
# Oracle Database: LSPD (PeopleSoft LS)
# =============================================================================

def connect_to_lsdb(
    config: dict[str, Any],
    logger: logging.Logger
):
    """
    Connect to the LSPD Oracle database and return a connection.

    Uses the ``oracledb`` library (thin or thick mode, depending on
    client library availability).

    Args:
        config: Configuration dict from ``load_config()``.
        logger: Logger instance.

    Returns:
        An ``oracledb.Connection`` ready for queries.

    Raises:
        oracledb.Error: On connection failure.
        ValueError: If required config keys are missing.
    """
    return _connect_to_oracle(config, 'ls_db', 'LSPD', logger)


# =============================================================================
# Oracle helpers
# =============================================================================

def _connect_to_oracle(
    config: dict[str, Any],
    config_key: str,
    display_name: str,
    logger: logging.Logger
):
    """
    Internal: connect to an Oracle database using oracledb.

    Args:
        config: Full configuration dict.
        config_key: Key in config dict ('hr_db' or 'ls_db').
        display_name: Human-readable name for log messages.
        logger: Logger instance.

    Returns:
        An ``oracledb.Connection``.
    """
    import oracledb

    db_cfg = config[config_key]
    _validate_keys(db_cfg, ['username', 'password', 'connect_string'], config_key)

    timeout = db_cfg.get('timeout', 30)

    logger.debug(
        f"Connecting to {display_name}: {db_cfg['connect_string']} "
        f"as {db_cfg['username']}"
    )

    conn = oracledb.connect(
        user=db_cfg['username'],
        password=db_cfg['password'],
        dsn=db_cfg['connect_string'],
        tcp_connect_timeout=timeout
    )

    logger.info(
        f"Connected to {display_name}: {db_cfg['connect_string']}"
    )
    return conn


# =============================================================================
# Helpers
# =============================================================================

def _validate_keys(
    cfg: dict[str, Any],
    required: list[str],
    section: str
) -> None:
    """Raise ValueError if any required config keys are missing/empty."""
    missing = [k for k in required if not cfg.get(k)]
    if missing:
        raise ValueError(
            f"Missing required config in [{section}]: {', '.join(missing)}"
        )
