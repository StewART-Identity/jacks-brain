"""
Flexible eDirectory User Lookup.

Provides a function to search for a user by any of the following attributes:
IDTREE mail, studentMail, employeeMail, workforceID, or euid.

This module uses the shared connection infrastructure from connections.py
rather than managing its own LDAP connection.
"""

from __future__ import annotations

import logging
from typing import Any

from .config import load_config
from .connections import connect_to_idtree

try:
    from ldap3 import SUBTREE
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False


def get_user_by_any_mail_or_id(
    identifier: str,
    config: dict[str, Any] | None = None,
    logger: logging.Logger | None = None
) -> dict[str, Any] | None:
    """
    Search for a user by mail, studentMail, employeeMail, workforceID,
    or euid in eDirectory.

    Args:
        identifier: The value to search for (email, workforceID, or euid).
        config: Optional pre-loaded config dict. If None, loads from .env.
        logger: Optional logger. If None, uses module-level logger.

    Returns:
        Dict of user attributes if found, or None if not found.
    """
    if not LDAP_AVAILABLE:
        raise ImportError(
            "ldap3 library is not available. "
            "Please install it to use this function."
        )

    if logger is None:
        logger = logging.getLogger(__name__)

    if config is None:
        config = load_config()

    search_base = config['edir']['base_dn']

    ldap_conn = None
    try:
        ldap_conn = connect_to_idtree(config, logger)

        from ldap3.utils.conv import escape_filter_chars
        safe = escape_filter_chars(identifier)
        search_filter = (
            f"(&(objectClass=person)"
            f"(|(mail={safe})"
            f"(studentMail={safe})"
            f"(employeeMail={safe})"
            f"(workforceID={safe})"
            f"(uid={safe})))"
        )

        logger.debug(f"Search base: {search_base}")
        logger.debug(f"Search filter: {search_filter}")

        success = ldap_conn.search(
            search_base, search_filter, SUBTREE, attributes='*'
        )

        if not success or not ldap_conn.entries:
            return None

        # Convert first entry to dict
        entry = ldap_conn.entries[0]
        result: dict[str, Any] = {'dn': entry.entry_dn}
        for attr in entry.entry_attributes:
            result[attr] = entry[attr].value

        logger.debug(
            f"Found user: {entry.entry_dn} "
            f"({len(result)} attributes)"
        )
        return result

    except Exception as e:
        logger.error(f"Error in get_user_by_any_mail_or_id: {e}")
        return None

    finally:
        if ldap_conn is not None:
            ldap_conn.unbind()
