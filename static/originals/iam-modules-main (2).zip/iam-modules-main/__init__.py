"""
IAM Modules — Shared libraries for UNT IAM scripts.

This package is the single point of contact for authentication,
configuration, and reusable clients across all IAM repositories.

    from iam_modules import load_config, setup_logging
    from iam_modules.connections import connect_to_edir, connect_to_ad
    from iam_modules.connections import connect_to_hrdb, connect_to_lsdb

Supported services:
    - eDirectory (IDTREE) — LDAP via ldap3 (test + prod environments)
    - Active Directory — Domain Controllers and Global Catalog
    - Microsoft Entra ID — Graph API via requests
    - Duo Security — Admin API
    - Oracle databases — HRPD, LSPD via oracledb
    - Configuration management via .env
    - Standardized logging to /var/log/iam
    - CLI utilities (prompts, paging, signal handling)
"""

# --- Config (always available) ---
from .config import (
    load_config,
    get_env_path,
    get_domain_config,
    get_edir_config,
    extract_domain_from_dn,
    # Centralized constants
    DEFAULT_LOG_DIR,
    DEFAULT_LOG_LEVEL,
    DEFAULT_SMTP_HOST,
    DEFAULT_SMTP_PORT,
    DEFAULT_EDIR_TIMEOUT,
    DEFAULT_AD_TIMEOUT,
    DEFAULT_GC_TIMEOUT,
    DEFAULT_DB_TIMEOUT,
    VALID_AD_DOMAINS,
    VALID_EDIR_ENVIRONMENTS,
    DOMAIN_DC_MAPPING,
    EXCLUDED_ENTRA_DOMAINS,
)

# --- Logging (always available) ---
from .logging_utils import setup_logging

# --- IDM Utilities (always available) ---
from .idm_utils import guid_to_association

# --- CLI Utilities (always available) ---
# Importing cli_utils registers the SIGINT handler automatically.
# Every script that imports iam_modules gets graceful Ctrl+C handling.
from .cli_utils import set_operation, run, prompt_yes_no, paged_output, handle_interrupt


# --- Lazy imports for optional dependencies ---

def get_ad_client():
    """Get ADDomainControllerClient class (requires ldap3)."""
    from .ad_client import ADDomainControllerClient
    return ADDomainControllerClient


def get_gc_client():
    """Get ADGlobalCatalogClient class (requires ldap3)."""
    from .gc_client import ADGlobalCatalogClient
    return ADGlobalCatalogClient


def get_graph_client():
    """Get GraphAPIClient class (requires requests)."""
    from .graph_client import GraphAPIClient
    return GraphAPIClient


def get_edir_client():
    """Get EDirectoryClient class (requires ldap3)."""
    from .edir_client import EDirectoryClient
    return EDirectoryClient


__all__ = [
    # Config
    'load_config',
    'get_env_path',
    'get_domain_config',
    'get_edir_config',
    'extract_domain_from_dn',
    # Constants
    'DEFAULT_LOG_DIR',
    'DEFAULT_LOG_LEVEL',
    'DEFAULT_SMTP_HOST',
    'DEFAULT_SMTP_PORT',
    'DEFAULT_EDIR_TIMEOUT',
    'DEFAULT_AD_TIMEOUT',
    'DEFAULT_GC_TIMEOUT',
    'DEFAULT_DB_TIMEOUT',
    'VALID_AD_DOMAINS',
    'VALID_EDIR_ENVIRONMENTS',
    'DOMAIN_DC_MAPPING',
    'EXCLUDED_ENTRA_DOMAINS',
    # Logging
    'setup_logging',
    # Utilities
    'guid_to_association',
    'set_operation',
    'run',
    'prompt_yes_no',
    'paged_output',
    'handle_interrupt',
    # Client factories (lazy)
    'get_ad_client',
    'get_gc_client',
    'get_graph_client',
    'get_edir_client',
]

__version__ = '3.1.0'
