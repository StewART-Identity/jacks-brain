"""
Shared TLS configuration for LDAP connections.

Single source of truth for TLS settings used by connections.py
and the client modules (edir_client, ad_client, gc_client).
"""

from __future__ import annotations

import ssl

from ldap3 import Tls


def edir_tls() -> Tls:
    """
    Return the TLS configuration required by UNT's eDirectory.

    eDirectory needs an explicit cipher string and TLSv1.2 pinning
    that the default ldap3 TLS configuration does not provide.
    """
    return Tls(
        validate=ssl.CERT_NONE,
        version=ssl.PROTOCOL_TLSv1_2,
        ciphers='HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5'
    )


def ad_tls() -> Tls:
    """Return the TLS configuration for Active Directory connections."""
    return Tls(validate=ssl.CERT_NONE)
