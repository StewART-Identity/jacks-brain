"""
eDirectory LDAP Client.

Provides LDAP operations for NetIQ eDirectory, which is used as the
identity vault in the UNT IAM infrastructure.

This client uses the production-correct TLS configuration (cipher string
and TLSv1.2 pinning) required by UNT's eDirectory servers.
"""

from __future__ import annotations

import logging
from typing import Any

# Optional LDAP support
try:
    import ldap3  # noqa: F401
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False


class EDirectoryClient:
    """
    Client for eDirectory LDAP operations.

    Provides methods for searching and modifying objects in eDirectory,
    including user accounts and their attributes.

    Example using from_config::

        from iam_modules import load_config, setup_logging

        config = load_config(__file__)
        logger = setup_logging('my_script')

        # New: explicit environment
        client = EDirectoryClient.from_config(config, logger, environment='prod')

        # Legacy: reads from config['edir'] (backward compatible)
        client = EDirectoryClient.from_config(config, logger)

        if client.connect():
            user = client.find_user_by_cn('jsmith')
            client.disconnect()
    """

    def __init__(self, hostname: str, port: int, use_ssl: bool,
                 username: str, password: str, base_dn: str,
                 logger: logging.Logger | None = None):
        self.hostname = hostname
        self.port = port
        self.use_ssl = use_ssl
        self.username = username
        self.password = password
        self.base_dn = base_dn
        self.logger = logger or logging.getLogger(__name__)
        self.connection: Any = None  # ldap3.Connection when connected

    @classmethod
    def from_config(cls, config: dict[str, Any],
                    logger: logging.Logger | None = None,
                    environment: str | None = None) -> 'EDirectoryClient':
        """
        Create an EDirectoryClient from a load_config() dict.

        Args:
            config: Configuration dict from load_config().
            logger: Optional logger instance.
            environment: eDirectory environment ('test', 'prod').
                         If None, uses the legacy ``config['edir']`` section
                         for backward compatibility.

        Returns:
            Configured (but not yet connected) EDirectoryClient.

        Raises:
            ValueError: If environment is provided but not valid.
        """
        if environment is not None:
            from .config import VALID_EDIR_ENVIRONMENTS
            env_lower = environment.lower()
            if env_lower not in VALID_EDIR_ENVIRONMENTS:
                raise ValueError(
                    f"Invalid eDirectory environment '{environment}'. "
                    f"Must be one of: {', '.join(VALID_EDIR_ENVIRONMENTS)}"
                )
            edir = config[f'edir_{env_lower}']
        else:
            edir = config['edir']

        return cls(
            hostname=edir['hostname'],
            port=edir['port'],
            use_ssl=edir['use_ssl'],
            username=edir['username'],
            password=edir['password'],
            base_dn=edir['base_dn'],
            logger=logger
        )

    def connect(self) -> bool:
        """
        Establish connection to eDirectory.

        Uses the TLS configuration required by UNT's eDirectory servers:
        explicit cipher string, TLSv1.2 pinning, and 600s connect timeout.

        Returns:
            True if connection successful, False otherwise
        """
        if not LDAP_AVAILABLE:
            self.logger.error(
                "ldap3 library not available. Install with: pip install ldap3"
            )
            return False

        from ldap3 import (
            Server as LdapServer,
            Connection as LdapConnection,
            ALL
        )
        from .tls import edir_tls

        try:
            self.logger.debug(
                f"Connecting to eDirectory: "
                f"{self.hostname}:{self.port} (SSL: {self.use_ssl})"
            )

            if self.use_ssl:
                server = LdapServer(
                    self.hostname, port=self.port,
                    use_ssl=True, tls=edir_tls(), get_info=ALL,
                    connect_timeout=600
                )
            else:
                server = LdapServer(
                    self.hostname, port=self.port,
                    get_info=ALL, connect_timeout=600
                )

            self.connection = LdapConnection(
                server,
                user=self.username,
                password=self.password,
                auto_bind=True,
                raise_exceptions=True
            )

            self.logger.debug("Successfully connected to eDirectory")
            return True

        except Exception as e:
            self.logger.error(f"Failed to connect to eDirectory: {e}")
            return False

    def disconnect(self) -> None:
        """Close the LDAP connection."""
        if self.connection:
            try:
                self.connection.unbind()
            except Exception:
                pass
            self.connection = None

    def search(self, search_filter: str, attributes: list[str] | None = None,
               search_base: str | None = None) -> list[dict[str, Any]]:
        """
        Search for objects in eDirectory.

        Args:
            search_filter: LDAP search filter
            attributes: List of attributes to return (None for all)
            search_base: Base DN for search (None uses client's base_dn)

        Returns:
            List of dicts with 'dn' and requested attributes
        """
        if not self.connection:
            return []

        from ldap3 import SUBTREE as LDAP_SUBTREE

        try:
            self.connection.search(
                search_base=search_base or self.base_dn,
                search_filter=search_filter,
                search_scope=LDAP_SUBTREE,
                attributes=attributes or ['*']
            )

            results = []
            for entry in self.connection.entries:
                result: dict[str, Any] = {'dn': str(entry.entry_dn)}
                for attr in entry.entry_attributes:
                    val = entry[attr].value
                    # Handle multi-valued attributes
                    if isinstance(val, list) and len(val) == 1:
                        val = val[0]
                    result[attr] = val
                results.append(result)

            return results

        except Exception as e:
            self.logger.error(f"Error searching eDirectory: {e}")
            return []

    def find_user_by_cn(self, cn: str) -> dict[str, Any] | None:
        """Find a user by their common name (cn)."""
        from ldap3.utils.conv import escape_filter_chars
        safe = escape_filter_chars(cn)
        search_filter = f"(&(objectClass=inetOrgPerson)(cn={safe}))"
        results = self.search(search_filter)
        return results[0] if results else None

    def find_user_by_uid(self, uid: str) -> dict[str, Any] | None:
        """Find a user by their uid attribute."""
        from ldap3.utils.conv import escape_filter_chars
        safe = escape_filter_chars(uid)
        search_filter = f"(&(objectClass=inetOrgPerson)(uid={safe}))"
        results = self.search(search_filter)
        return results[0] if results else None

    def find_user_by_workforce_id(self, workforce_id: str) -> dict[str, Any] | None:
        """Find a user by their workforceID attribute."""
        from ldap3.utils.conv import escape_filter_chars
        safe = escape_filter_chars(workforce_id)
        search_filter = f"(&(objectClass=inetOrgPerson)(workforceID={safe}))"
        results = self.search(search_filter)
        return results[0] if results else None

    def find_user_by_email(self, email: str) -> dict[str, Any] | None:
        """Find a user by their mail attribute."""
        from ldap3.utils.conv import escape_filter_chars
        safe = escape_filter_chars(email)
        search_filter = f"(&(objectClass=inetOrgPerson)(mail={safe}))"
        results = self.search(search_filter)
        return results[0] if results else None

    def get_user_attributes(self, dn: str, attributes: list[str]) -> dict[str, Any] | None:
        """
        Get specific attributes for a user by DN.

        Args:
            dn: Distinguished name of the user
            attributes: List of attributes to retrieve

        Returns:
            Dict of attributes or None if not found
        """
        try:
            self.connection.search(
                search_base=dn,
                search_filter='(objectClass=*)',
                search_scope='BASE',
                attributes=attributes
            )

            if self.connection.entries:
                entry = self.connection.entries[0]
                result: dict[str, Any] = {'dn': str(entry.entry_dn)}
                for attr in attributes:
                    if hasattr(entry, attr):
                        val = entry[attr].value
                        result[attr] = val
                return result

            return None

        except Exception as e:
            self.logger.error(f"Error getting attributes for '{dn}': {e}")
            return None

    def modify_attribute(self, dn: str, attribute: str, value: Any,
                         operation: str = 'replace', dry_run: bool = False) -> bool:
        """
        Modify an attribute on an eDirectory object.

        Args:
            dn: Distinguished name of the object
            attribute: Name of the attribute to modify
            value: New value(s) for the attribute
            operation: 'replace', 'add', or 'delete'
            dry_run: If True, log the action but don't execute it

        Returns:
            True if successful, False on error
        """
        if not self.connection:
            return False

        if dry_run:
            self.logger.info(f"[DRY-RUN] Would {operation} '{attribute}' on '{dn}'")
            return True

        from ldap3 import MODIFY_REPLACE, MODIFY_ADD, MODIFY_DELETE

        op_map = {
            'replace': MODIFY_REPLACE,
            'add': MODIFY_ADD,
            'delete': MODIFY_DELETE
        }

        ldap_op = op_map.get(operation.lower())
        if not ldap_op:
            self.logger.error(f"Invalid operation: {operation}")
            return False

        try:
            if not isinstance(value, list):
                value = [value]

            self.connection.modify(
                dn,
                {attribute: [(ldap_op, value)]}
            )

            self.logger.debug(f"Successfully modified '{attribute}' on '{dn}'")
            return True

        except Exception as e:
            self.logger.error(f"Error modifying attribute: {e}")
            return False

    def get_drv_association(self, dn: str) -> str | None:
        """
        Get the DirXML-Association (driver association) attribute for an object.

        Args:
            dn: Distinguished name of the object

        Returns:
            Association value string or None
        """
        result = self.get_user_attributes(dn, ['DirXML-Associations'])
        if result and 'DirXML-Associations' in result:
            return result['DirXML-Associations']
        return None
