"""
CLI utilities for IAM scripts.

Provides common CLI helpers like prompts, paged output, and signal handling.

The SIGINT handler is registered automatically when this module is imported
(which happens on ``from iam_modules import ...``).  Scripts update the
current operation via ``set_operation()`` so that Ctrl+C always prints a
clean, human-readable message instead of a Python traceback.
"""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import tempfile
from typing import Callable


# =============================================================================
# Graceful Ctrl+C Handling
# =============================================================================

_current_operation: str = 'initializing'


def set_operation(description: str) -> None:
    """
    Set the current operation description for Ctrl+C messages.

    Call this as your script moves through phases so that if the user
    presses Ctrl+C, they see where processing was interrupted.

    Args:
        description: Human-readable description of what the script is doing.

    Example::

        set_operation('connecting to eDirectory')
        conn = connect_to_idtree(config, logger)

        set_operation('searching for expiring passwords (5-day window)')
        accounts = find_expiring_passwords(...)

        for i, acct in enumerate(accounts, 1):
            set_operation(f'sending notice to {acct["euid"]} ({i}/{len(accounts)})')
            send_email(...)
    """
    global _current_operation
    _current_operation = description


def _handle_interrupt(signum: int, frame) -> None:
    """
    SIGINT handler that prints where processing was interrupted.

    Registered automatically on module import.  Never produces a traceback.
    """
    print(f"\n\nInterrupted during: {_current_operation}")
    print("No further changes will be made.")
    sys.exit(130)  # Standard exit code for SIGINT


def handle_interrupt(signum: int, frame) -> None:
    """
    Legacy handler kept for backward compatibility.

    New scripts should use ``set_operation()`` instead.
    """
    _handle_interrupt(signum, frame)


def register_interrupt_handler() -> None:
    """Register the interrupt handler. Called automatically on module import."""
    signal.signal(signal.SIGINT, _handle_interrupt)


# Register on import — every script that touches iam_modules gets this
register_interrupt_handler()


def run(main_func: Callable[[], int]) -> None:
    """
    Run a script's main() with complete interrupt protection.

    This catches KeyboardInterrupt that escapes the signal handler
    (e.g., when Python is blocked inside C-level I/O like SSL socket
    reads or Oracle network calls).

    Usage::

        if __name__ == '__main__':
            from iam_modules import run
            run(main)

    Args:
        main_func: The script's main() function, which should return
                   an int exit code (0 for success, non-zero for failure).
    """
    try:
        sys.exit(main_func())
    except KeyboardInterrupt:
        print(f"\n\nInterrupted during: {_current_operation}")
        print("No further changes will be made.")
        sys.exit(130)


# =============================================================================
# Prompts
# =============================================================================

def prompt_yes_no(message: str, default: bool = False) -> bool:
    """
    Prompt the user for a yes/no response.

    Args:
        message: The prompt message to display
        default: Default value if user just presses Enter

    Returns:
        True for yes, False for no

    Raises:
        KeyboardInterrupt: If user types 'q' or presses Ctrl+C

    Example:
        if prompt_yes_no("Do you want to continue?"):
            print("Continuing...")
    """
    suffix = " [y/N/q]: " if not default else " [Y/n/q]: "
    try:
        response = input(message + suffix).strip().lower()
        if not response:
            return default
        if response in ('q', 'quit', 'exit'):
            raise KeyboardInterrupt("User requested quit")
        return response in ('y', 'yes')
    except EOFError:
        print()
        return False


def prompt_choice(message: str, choices: list[str], default: str | None = None) -> str:
    """
    Prompt the user to select from a list of choices.

    Args:
        message: The prompt message to display
        choices: List of valid choices
        default: Default choice if user just presses Enter

    Returns:
        The selected choice (lowercase)

    Raises:
        KeyboardInterrupt: If user types 'q' or presses Ctrl+C
    """
    choices_lower = [c.lower() for c in choices]
    choices_str = '/'.join(choices)

    if default:
        suffix = f" [{choices_str}] (default: {default}): "
    else:
        suffix = f" [{choices_str}]: "

    while True:
        try:
            response = input(message + suffix).strip().lower()

            if not response and default:
                return default.lower()

            if response in ('q', 'quit', 'exit'):
                raise KeyboardInterrupt("User requested quit")

            if response in choices_lower:
                return response

            print(f"Invalid choice. Please enter one of: {choices_str}")

        except EOFError:
            print()
            if default:
                return default.lower()
            raise KeyboardInterrupt("EOF received")


# =============================================================================
# Paged Output
# =============================================================================

def paged_output(content: str) -> None:
    """
    Display content through a pager (like less) if it exceeds terminal height.
    Falls back to direct print if pager is unavailable or content is short.

    Args:
        content: The text content to display

    Example:
        paged_output("\\n".join(["Line " + str(i) for i in range(1000)]))
    """
    terminal_size = shutil.get_terminal_size(fallback=(80, 24))
    content_lines = content.count('\n') + 1

    if content_lines <= terminal_size.lines - 2:
        print(content)
        return

    pagers = ['less', 'more']

    for pager in pagers:
        if shutil.which(pager):
            temp_path: str | None = None
            try:
                with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                    f.write(content)
                    temp_path = f.name

                pager_cmd = [pager]
                if pager == 'less':
                    pager_cmd.extend(['-R', '-S'])
                pager_cmd.append(temp_path)

                subprocess.run(pager_cmd)
                os.unlink(temp_path)
                return
            except Exception:
                if temp_path:
                    try:
                        os.unlink(temp_path)
                    except Exception:
                        pass
                continue

    print(content)


# =============================================================================
# Colored Output Helpers
# =============================================================================

def print_result(name: str, success: bool, message: str = "") -> None:
    """Print a formatted test/operation result with color."""
    status = "[OK]" if success else "[X]"
    color_start = "\033[92m" if success else "\033[91m"
    color_end = "\033[0m"

    print(f"{color_start}{status}{color_end} {name}")
    if message and message != "Connection successful":
        print(f"    {message}")


def print_warning(message: str) -> None:
    """Print a warning message in yellow."""
    print(f"\033[93mWARNING: {message}\033[0m")


def print_error(message: str) -> None:
    """Print an error message in red."""
    print(f"\033[91mERROR: {message}\033[0m")


def print_success(message: str) -> None:
    """Print a success message in green."""
    print(f"\033[92m{message}\033[0m")


def print_info(message: str) -> None:
    """Print an info message in cyan."""
    print(f"\033[96mINFO: {message}\033[0m")
